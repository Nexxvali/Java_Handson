import java.util.Scanner;
import java.util.StringTokenizer;

public class WordCountII 
{
	public static int countWord(String s)
	{
		StringTokenizer st=new StringTokenizer(s);
		return st.countTokens();
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
        String s=in.nextLine();
        System.out.println(WordCountII.countWord(s));
	}
}
