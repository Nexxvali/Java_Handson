import java.util.Scanner;

public class VowelCheck 
{
	static int getVowels(String str)
	{
		if(str.contains("a")&&str.contains("e")&&str.contains("i")&&str.contains("o")&&str.contains("u"))
			return 1;
		else
			return -1;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		if(VowelCheck.getVowels(s)==1)
			System.out.println("yes");
		else
			System.out.println("no");
	}
}
