import java.util.Scanner;
import java.util.StringTokenizer;

public class LongestWord 
{
	static String compareLastWords(String str)
	{
		StringTokenizer st=new StringTokenizer(str);
		String max=st.nextToken(),temp;
		while(st.hasMoreTokens())
		{
			temp=st.nextToken();
			if(temp.length()>max.length())
				max=new String(temp);
		}
		return max;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String str=in.nextLine();
		System.out.println(LongestWord.compareLastWords(str));
	}
}
