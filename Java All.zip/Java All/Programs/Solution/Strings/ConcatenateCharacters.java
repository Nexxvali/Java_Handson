import java.util.Scanner;

public class ConcatenateCharacters 
{
	public static String concatCharacter(String str[])
    {
		String s="";
		for(int i=0;i<str.length;i++)
			s=s+str[i].charAt(str[i].length()-1);
		return s;
    }
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
        int n=Integer.parseInt(in.nextLine());
        String[] s=new String[n];
        for(int i=0;i<n;i++)
        	s[i]=in.nextLine();
		System.out.println(ConcatenateCharacters.concatCharacter(s));
	}
}
