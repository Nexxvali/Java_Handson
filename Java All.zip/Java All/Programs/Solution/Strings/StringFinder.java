import java.util.Scanner;

public class StringFinder 
{
	static int stringFinder(String str,String str1,String str2)
	{	
		int i1=str.indexOf(str1);
		int i2=str.lastIndexOf(str2);
		if(i1<i2)
			return 1;
		return 2;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		String s1=in.nextLine();
		String s2=in.nextLine();
		if(StringFinder.stringFinder(s,s1,s2)==1)
			System.out.println("yes");
		else
			System.out.println("no");
	}
}