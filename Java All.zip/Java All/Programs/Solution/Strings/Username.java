import java.util.Scanner;

public class Username 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(Username.fetchUserName(s));
	}
	public static String fetchUserName(String str) 
	{
		return str.substring(0,str.indexOf("@"));
	}
}
