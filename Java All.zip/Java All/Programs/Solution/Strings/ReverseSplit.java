import java.util.Scanner;

public class ReverseSplit 
{
	static String reshape(String str,char c)
	{
		return new StringBuffer(str.replaceAll("(.)","$1"+c)).reverse().substring(1);
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String str=in.nextLine();
		char c=in.nextLine().charAt(0);
		System.out.println(ReverseSplit.reshape(str,c));
	}

}
