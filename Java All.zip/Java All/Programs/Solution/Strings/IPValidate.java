import java.util.Scanner;
import java.util.StringTokenizer;

public class IPValidate 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		int b=IPValidate.ipValidator(s);
		if(b==1)
			System.out.println("Valid");
		else
			System.out.println("Invalid");
	}

	public static int ipValidator(String s) 
	{
		if(s.matches("[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}"))
		{
			StringTokenizer st=new StringTokenizer(s,".");
			for(int i=0;i<4&&st.hasMoreTokens();i++)
			{
				int k=Integer.parseInt(st.nextToken().toString());
				if(k>=0&&k<=255)
				{
					if(i==3)
						return 1;
				}
				else
					return 2;
			}
		}
		return 2;
	}
}
