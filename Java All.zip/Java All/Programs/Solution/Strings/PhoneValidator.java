import java.util.Scanner;

public class PhoneValidator 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		System.out.println((PhoneValidator.validatePhone(s)+"").toUpperCase());
	}
	public static boolean validatePhone(String s) 
	{
		return s.matches("^00.*")==false&&s.matches("[0-9]{10}");
	}
}
