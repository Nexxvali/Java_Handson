import java.util.Scanner;
import java.util.StringTokenizer;

public class MaxScorer 
{
	static String highestScorer(String ar[])
	{
		String name="";
		int score=0;
		for(int i=0;i<ar.length;i++)
		{
			StringTokenizer st=new StringTokenizer(ar[i],"-");
			String tname=st.nextToken();
			int tscore=0;
			for(int j=0;j<3;j++)
				tscore=tscore+Integer.parseInt(st.nextToken());
			if(tscore>score)
			{
				score=tscore;
				name=new String(tname);
			}
		}
		return name;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
		String a[]=new String[n];
		for(int i=0;i<n;i++)
			a[i]=in.nextLine();
		System.out.println(MaxScorer.highestScorer(a));
	}
}
