import java.util.Arrays;
import java.util.Scanner;

public class PlayingStringII 
{
	public static String[] sortArray(String s[])
	{
		for(int i=0;i<s.length;i++)
			s[i]=s[i].toLowerCase();
		Arrays.sort(s);
		return s;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
        int n=Integer.parseInt(in.nextLine());
        String[] a=new String[n];
        for(int i=0;i<n;i++)
        	a[i]=in.nextLine();
        for(String s:PlayingStringII.sortArray(a))
        	System.out.println(s);
	}
}
