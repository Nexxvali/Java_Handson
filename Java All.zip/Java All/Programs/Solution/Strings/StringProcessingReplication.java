import java.util.Scanner;

public class StringProcessingReplication 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		int n=in.nextInt();
		System.out.println(StringProcessingReplication.repeatString(s,n));
	}

	public static String repeatString(String str,int n) 
	{
		String s1=new String(str);
		for(int i=1;i<n;i++)
			s1=s1.concat(str);
		return s1;
	}
}
