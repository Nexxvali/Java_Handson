import java.util.Scanner;

public class RegularExpressionII 
{
	static boolean validateString(String str)
	{	
		if(str.matches("[a-zA-Z]{3}"))
			return true;
		return false;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println((RegularExpressionII.validateString(s)+"").toUpperCase());
	}
}
