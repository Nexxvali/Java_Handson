import java.util.Scanner;

public class StringProcessingV 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		in.nextLine();
		String s[]=new String[n];
		for(int i=0;i<n;i++)
			s[i]=in.nextLine();
		System.out.println(StringProcessingV.concatString(s));
	}

	public static String concatString(String str[]) 
	{
		String s=new String(str[0]);
		for(int i=1;i<str.length;i++)
			s=s+","+str[i];
		return s;
	}
}
