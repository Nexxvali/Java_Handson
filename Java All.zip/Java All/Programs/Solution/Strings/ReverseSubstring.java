import java.util.Scanner;

public class ReverseSubstring 
{
	static String reverseSubstring(String str,int s,int e)
	{
		/*StringBuffer sb=new StringBuffer(str);
		sb.reverse();
		String s1=sb.toString();
		return s1.substring(s,s+e);*/
		return new StringBuffer(str).reverse().substring(s,s+e).toString();
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String str=in.next();
		int s=in.nextInt();
		int e=in.nextInt();
		System.out.println(ReverseSubstring.reverseSubstring(str,s,e));
	}
}
