import java.util.Scanner;

public class PatternMatcher 
{
	public static boolean CheckID(String s)
	{
		return s.matches("CPT-[0-9]{6}");
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		if(PatternMatcher.CheckID(s))
			System.out.println("Valid");
		else
			System.out.println("Invalid");
	}
}