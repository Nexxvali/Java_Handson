import java.util.Scanner;

public class AllVowels 
{
	static int getVowels(String str)
	{
	 	str=str.toLowerCase();
	 	String s=str.replaceAll("[^aeiou]","");
		if(s.equals("aeiou"))
			return 1;
		return -1;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		if(getVowels(s)==1)
			System.out.println("yes");
		else
			System.out.println("no");
	}
}