import java.util.Scanner;

public class LargestSpan 
{
	static int getMaxSpan(int ar[])
	{
		String str="";
		int max=0;
		for(int a:ar)
			str=str+a;
		for(int i=0;i<str.length();i++)
		{
			int span=str.lastIndexOf(str.charAt(i))-str.indexOf(str.charAt(i))+1;
			if(span>max)
				max=span;
		}
		return max;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=in.nextInt();
		System.out.println(LargestSpan.getMaxSpan(a));
	}
}
