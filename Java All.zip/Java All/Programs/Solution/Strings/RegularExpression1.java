import java.util.Scanner;

public class RegularExpression1 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		System.out.println((RegularExpression1.validate(s)+"").toUpperCase());
	}
	public static boolean validate(String s) 
	{
		return s.matches("[a-zA-Z0-9]R[0-9].");
	}
}
