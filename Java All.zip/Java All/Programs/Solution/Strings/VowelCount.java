import java.util.Scanner;

public class VowelCount 
{
	static int tellVowelCount(String str)
	{
		return str.replaceAll("[^aeiouAEIOU]","").length();
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(VowelCount.tellVowelCount(s));
	}
}
