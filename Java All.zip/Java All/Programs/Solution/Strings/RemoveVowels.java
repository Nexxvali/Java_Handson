public class RemoveVowels 
{
	static String removeEvenVowels(String str)
	{
		int i=0;
		char c;
		StringBuffer s=new StringBuffer();
		int len=str.length();
		while(i<len)
		{
			c=str.charAt(i);
			if((i+1)%2==0)
			{
				if(!(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||c=='A'||c=='E'||c=='I'||c=='O'||c=='U'))
					s.append(c);
			}
			else
				s.append(c);
			i++;
		}
		return s.toString();
	}
	public static void main(String[] args) 
	{
		java.util.Scanner in=new java.util.Scanner(System.in);
		String str=in.next();
		System.out.println(RemoveVowels.removeEvenVowels(str));
	}

}
