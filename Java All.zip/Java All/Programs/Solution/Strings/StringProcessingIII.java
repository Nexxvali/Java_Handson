import java.util.Scanner;

public class StringProcessingIII 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(StringProcessingIII.moveX(s));
	}

	public static String moveX(String str) 
	{
		StringBuffer sb=new StringBuffer(str);
		int i,j=0;
		for(i=0;i<sb.length();)
		{
			if(sb.charAt(i)=='x')
			{
				sb.deleteCharAt(i);
				j++;
			}
			else
				i++;
		}
		for(i=0;i<j;i++)
			sb.append('x');
		return sb.toString();
	}
}
