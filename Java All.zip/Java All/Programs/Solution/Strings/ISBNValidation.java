import java.util.Scanner;

public class ISBNValidation 
{
	static boolean validateISBN(String str)
	{	
		if(str.matches("[0-9]{10}"))
		{
			int i=10,sum=0;
			for(int j=0;j<10;j++,i--)
				sum=sum+i*Integer.parseInt(str.charAt(j)+"");
			if(sum%11==0)
				return true;
		}
		return false;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println((ISBNValidation.validateISBN(s)+"").toUpperCase());
	}
}
