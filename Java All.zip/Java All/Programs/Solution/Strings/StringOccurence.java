import java.util.Scanner;
import java.util.StringTokenizer;

public class StringOccurence 
{
	static int countNoOfWords(String s1,String s2)
	{	
		StringTokenizer st=new StringTokenizer(s2);
		String s=st.nextToken();
		s=st.nextToken();
		return s1.replaceAll(s,"\\$").replaceAll("[^$]","").length();
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s1=in.nextLine();
		String s2=in.nextLine();
		System.out.println(StringOccurence.countNoOfWords(s1,s2));
	}
}
