import java.util.Scanner;

public class Password 
{
	public static boolean validatePassword(String s)
	{
        if(s.length()>=8&&s.matches(".*[0-9].*")&&s.matches(".*[a-zA-Z].*")&&s.matches(".*[^0-9a-zA-Z].*"))
           return true;
      	return false;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		if(Password.validatePassword(s))
			System.out.println("Valid");
		else
			System.out.println("Invalid");
	}
}
