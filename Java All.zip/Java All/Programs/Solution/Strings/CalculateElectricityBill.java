import java.util.Scanner;

public class CalculateElectricityBill 
{
	public static int meterReading(String input1, String input2, int input3)
    {
		int n1=Integer.parseInt(input1.substring(5, input1.length()));
		int n2=Integer.parseInt(input2.substring(5, input2.length()));
		int n=Math.abs((n2-n1)*input3);
		return n;
    }
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		String s1=in.nextLine();
		int n=in.nextInt();
		System.out.println(CalculateElectricityBill.meterReading(s,s1,n));
	}
}
