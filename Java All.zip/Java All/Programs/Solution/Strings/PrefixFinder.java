import java.util.*;

public class PrefixFinder 
{
	public static int findPrefix(String s[])
	{
		Arrays.sort(s);
		int c=0;
		for(int i=0;i<s.length;i++)
		{
			for(int j=i+1;j<s.length;j++)
			{
				if(s[i].equals(s[j]))
					break;
				if(s[j].matches("^"+s[i]+"[10]{1,}"))
					++c;
			}
		}
		return c;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
        int n=Integer.parseInt(in.nextLine());
        String[] a=new String[n];
        for(int i=0;i<n;i++)
        	a[i]=in.nextLine();
        System.out.println(findPrefix(a));
	}
}