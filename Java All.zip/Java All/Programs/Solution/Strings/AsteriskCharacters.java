import java.util.Scanner;

public class AsteriskCharacters 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		System.out.println((AsteriskCharacters.scanStarNeighbors(s)+"").toUpperCase());
	}
	public static boolean scanStarNeighbors(String s) 
	{
		String search="",rest=new String(s);
		int i=0;
		i=s.indexOf("*");
		while(i!=-1&&i<s.length()-1)
		{
			search=rest.substring(0,i);
			rest=rest.substring(i+1);
			if(rest.equals("")||search.charAt(search.length()-1)!=rest.charAt(0))
				return false;
			i=rest.indexOf("*");
		}
		if(i==s.lastIndexOf("*")&&i<s.length()-1||i==-1)
			return true;
		return false;
	}
}
