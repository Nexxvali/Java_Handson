import java.util.Scanner;

public class RemoveElement 
{
	public static int removeElements(String s[],int n,int m)
	{
		int alen=n;
		for(int i=0;i<n;i++)
		{
			if(s[i].length()==m)
				alen--;
		}
		return alen;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        String[] a=new String[n];
        for(int i=0;i<n;i++)
        	a[i]=in.nextLine();
        int m=in.nextInt();
        System.out.println(RemoveElement.removeElements(a,n,m));

	}
}
