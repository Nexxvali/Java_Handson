import java.util.Scanner;

public class ConvertFormat 
{
	public static String convertFormat(String str)
    {
		return str.replaceAll("(..)(.)-(.)(..)-(.)(..)","$1-$2$3-$4$5-$6");
    }
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(ConvertFormat.convertFormat(s));
	}
}
