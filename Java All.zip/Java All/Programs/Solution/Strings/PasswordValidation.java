import java.util.Scanner;

public class PasswordValidation 
{
	public static int display(String password)
	{
        if(password.matches(".*[0-9]{1,}.*") && password.matches(".*[@#$]{1,}.*") && password.length()>=6 && password.length()<=20)
           return 1;
        else
        	return -1;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		int i=PasswordValidation.display(s);
		if(i==-1)
			System.out.println("Invalid password");
		else
			System.out.println("Valid password");
	}
}
