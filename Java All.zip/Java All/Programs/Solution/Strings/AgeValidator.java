import java.util.Scanner;

public class AgeValidator 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		System.out.println((AgeValidator.validateAge(s)+"").toUpperCase());
	}
	public static boolean validateAge(String s) 
	{
		return s.matches("[0-9]{2}")&&Integer.parseInt(s)>=21&&Integer.parseInt(s)<=45;
	}
}
