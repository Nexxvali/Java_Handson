import java.util.Scanner;

public class FindCommonUniqueCharacter 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s1=in.nextLine();
		String s2=in.nextLine();
		System.out.println(FindCommonUniqueCharacter.commonChars(s1,s2));
	}
	public static int commonChars(String s1,String s2) 
	{
		s1=s1.replaceAll("\\s","");
		s2=s2.replaceAll("\\s","");
		int i,j,count=0;
		String s,temp,temp2=new String(s1);
		for(i=0;i<s1.length();i++)
		{
			s=s1.substring(i+1,s1.length());
			temp=s1.charAt(i)+"";
			if(s.contains(temp))
				temp2=temp2.replaceAll(temp,"");
		}
		s1=new String(temp2);
		temp2=new String(s2);
		for(i=0;i<s2.length();i++)
		{
			s=s2.substring(i+1,s2.length());
			temp=s2.charAt(i)+"";
			if(s.contains(temp))
				temp2=temp2.replaceAll(temp,"");
		}
		s2=new String(temp2);
		for(i=0;i<s1.length();i++)
			for(j=0;j<s2.length();j++)
				if(s1.charAt(i)==s2.charAt(j))
				{
					count++;
					break;
				}
		return count;
	}
}