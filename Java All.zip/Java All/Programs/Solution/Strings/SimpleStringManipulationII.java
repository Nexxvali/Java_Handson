import java.util.Scanner;

public class SimpleStringManipulationII 
{
	static int calculateWordSum(String str)
	{
		String start=str.substring(0,str.indexOf(" "));
		String end=str.substring(str.lastIndexOf(" ")+1);
		if(start.equals(end))
			return start.length();
		return start.length()+end.length();
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String str=in.nextLine();
		System.out.println(SimpleStringManipulationII.calculateWordSum(str));
	}
}
