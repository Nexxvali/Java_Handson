import java.util.Scanner;

public class StringProcessingVII
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s1=in.nextLine();
		String s2=in.nextLine();
		int n=in.nextInt();
		System.out.println((StringProcessingVII.isEqual(s1,s2,n)+"").toUpperCase());
	}

	public static boolean isEqual(String s1,String s2,int n) 
	{
		return (s1.toUpperCase().charAt(n-1)==s2.toUpperCase().charAt(s2.length()-n));
	}
}
