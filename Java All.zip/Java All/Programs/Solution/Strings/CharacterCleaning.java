import java.util.Scanner;

public class CharacterCleaning 
{ 
	static String removeCharacter(String str,char c)
	{	
		return str.replace(c+"","");
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		char c=in.nextLine().charAt(0);
		System.out.println(CharacterCleaning.removeCharacter(s,c));
	}
}
