import java.util.Scanner;
import java.util.StringTokenizer;

public class StringSplitter 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		char c=in.nextLine().charAt(0);
		for(String a:StringSplitter.validatePhone(s,c))
			System.out.println(a);
	}
	public static String[] validatePhone(String s,char c) 
	{
		StringTokenizer st=new StringTokenizer(s,c+"");
		String str[]=new String[st.countTokens()];
		int i=0;
		while(st.hasMoreTokens())
			str[i++]=new StringBuffer(st.nextToken()).reverse().toString().toLowerCase();
		return str;
	}
}
