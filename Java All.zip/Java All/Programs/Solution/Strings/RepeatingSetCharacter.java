import java.util.Scanner;

public class RepeatingSetCharacter 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		int n=in.nextInt();
		System.out.println(RepeatingSetCharacter.getString(s,n));
	}

	public static String getString(String s,int n) 
	{
		String s1=s.substring(s.length()-n,s.length());
		String s2=new String(s);
		for(int i=0;i<n;i++)
			s2=s2.concat(s1);
		return s2;
	}
}
