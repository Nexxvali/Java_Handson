import java.util.Scanner;

public class PANCard
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		String pan=s.next();
		int b=PANCard.validatePAN(pan);
		if(b==1)
			System.out.println("Valid");
		else
			System.out.println("Invalid");
	}
	public static int validatePAN(String input) 
	{
		int b=0;
		if(input.matches("[A-Z]{3}[0-9]{4}[A-Z]{1}"))
			b=1;
		else
			b=2;
		return b;
	}
}
