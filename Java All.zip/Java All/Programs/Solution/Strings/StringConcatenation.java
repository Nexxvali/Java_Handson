
public class StringConcatenation 
{
	static String concatString(String str1,String str2)
	{
		int len1=str1.length();
		int len2=str2.length();
		if(len1==len2)
			return str1.concat(str2);
		else
		{
			if(len1>len2)
			{
				return str1.substring(len1-len2,len1).concat(str2);
			}
			else if(len2>len1)
			{
				return str1.concat(str2.substring(len2-len1,len2));
			}
		}
		return "";
	}
	public static void main(String[] args) 
	{
		java.util.Scanner in=new java.util.Scanner(System.in);
		String str=in.next();
		String str1=in.next();
		System.out.println(StringConcatenation.concatString(str, str1));
	}
}
