import java.util.Scanner;

public class StringProcessingV1 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		int n=in.nextInt();
		System.out.println(StringProcessingV1.returnLastRepeatedCharacters(s,n));
	}

	public static String returnLastRepeatedCharacters(String str,int n) 
	{
		String s=str.substring(str.length()-n,str.length());
		String s1="";
		for(int i=0;i<n;i++)
			s1=s1.concat(s);
		return s1;
	}
}
