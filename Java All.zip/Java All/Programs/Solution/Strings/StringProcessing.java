import java.util.Scanner;

public class StringProcessing 
{
	static String exchangeCharacters(String str)
	{	
		return str.charAt(str.length()-1)+"".concat(str.substring(1,str.length()-1)).concat(str.charAt(0)+"");
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(StringProcessing.exchangeCharacters(s));
	}
}
