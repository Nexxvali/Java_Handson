import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;

public class Commons 
{
	public static int countCommon(String ss1[],String ss2[])
	{
		HashSet<String> h=new HashSet<String>(Arrays.asList(ss1));
		String s1[]=new String[h.size()];
		h.toArray(s1);
		h=new HashSet<String>(Arrays.asList(ss2));
		String s2[]=new String[h.size()];
		h.toArray(s2);
		int count=0;
		for(int i=0;i<s1.length;i++)
		{	
			for(int j=0;j<s2.length;j++)
			{
				if(s1[i].equals(s2[j]))
					count++;
			}
		}
		return count;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
        int n=Integer.parseInt(in.nextLine());
        String[] a1=new String[n];
        for(int i=0;i<n;i++)
        	a1[i]=in.nextLine();
        n=Integer.parseInt(in.nextLine());
        String[] a2=new String[n];
        for(int i=0;i<n;i++)
        	a2[i]=in.nextLine();
        System.out.println(Commons.countCommon(a1,a2));

	}
}
