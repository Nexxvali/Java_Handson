import java.util.Scanner;
import java.util.StringTokenizer;

public class StartCase 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(StartCase.printCapitalized(s));
	}

	public static String printCapitalized(String s) 
	{
		StringTokenizer st=new StringTokenizer(s);
		String str="",temp;
		while(st.hasMoreTokens())
		{
			temp=st.nextToken();
			str=str+(temp.charAt(0)+"").toUpperCase()+temp.substring(1)+" ";
		}
		return str.substring(0,str.length()-1);
	}
}
