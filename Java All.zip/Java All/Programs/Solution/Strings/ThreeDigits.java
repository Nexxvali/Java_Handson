import java.util.Scanner;

public class ThreeDigits 
{
	public static int validatestrings(String s)
	{
		if(s.matches("(CTS)[-]{1}[0-9]{3}"))
			return 1;
		else
			return -1;

	}
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		String str=s.next();
		int b=ThreeDigits.validatestrings(str);
		if(b==1)
			System.out.println("Valid");
		else
			System.out.println("Invalid");
	}
}
