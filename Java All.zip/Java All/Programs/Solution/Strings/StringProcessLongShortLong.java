import java.util.Scanner;

public class StringProcessLongShortLong 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s1=in.nextLine();
		String s2=in.nextLine();
		System.out.println(StringProcessLongShortLong.getCombo(s1,s2));
	}

	public static String getCombo(String s1,String s2) 
	{
		if(s1.length()>s2.length())
			return s1+s2+s1;
		return s2+s1+s2;
	}
}
