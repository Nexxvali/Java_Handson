import java.util.Scanner;

public class RegularExpressionsIII 
{
	static boolean validateString(String str)
	{	
		if(str.matches("^[^0-9].*"))
			return true;
		return false;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(RegularExpressionsIII.validateString(s));
	}
}
