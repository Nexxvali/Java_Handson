import java.util.Scanner;

public class FindDigits 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		double s=in.nextDouble();
		System.out.println(FindDigits.findNoDigits(s));
	}

	public static String findNoDigits(double d) 
	{
		String s=String.valueOf(d);
		String res="";
		if(s.matches("([0-9][0-9]*)?(\\.[0-9][0-9]*)?"))
		{
			
			s=s.replaceAll("^0*(.*)", "$1");
			s=new StringBuffer(s).reverse().toString().replaceAll("^0*(.*)", "$1");
			s=new StringBuffer(s).reverse().toString();
			if(s.indexOf(".")==0)
				res=res+"0";
			else
				res=res+(s.indexOf("."));
			if(s.indexOf(".")==s.length()-1)
				res=res+":1";
			else
				res=res+":"+((s.length()-s.indexOf(".")-1));
		}
		return res;
	}
}
