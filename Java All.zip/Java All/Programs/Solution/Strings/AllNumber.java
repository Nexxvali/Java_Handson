import java.util.Scanner;

public class AllNumber 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
		String s[]=new String[n];
		for(int i=0;i<n;i++)
			s[i]=in.next();
		int b=AllNumber.validateNumber(s);
		if(b==1)
			System.out.println("Valid");
		else
			System.out.println("Invalid");
	}

	public static int validateNumber(String s[]) 
	{
		int i;
		for(i=0;i<s.length;i++)
		{
			if(!s[i].matches("([0-9][0-9]*)?(\\.[0-9][0-9]*)?"))
				break;
		}
		System.out.println(i);
		if(i==s.length)
			return 1;
		return -1;
	}
}
