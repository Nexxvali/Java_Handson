import java.util.Scanner;
import java.util.StringTokenizer;

public class LengthLargestChunk 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		int r=LengthLargestChunk.largestChunk(s);
		if(r==0||r==1)
			System.out.println("No Chunks");
		else
			System.out.println(r);
	}

	public static int largestChunk(String s) 
	{
		int c,max=0,i=0,j=0;
		StringTokenizer st=new StringTokenizer(s);
		while(st.hasMoreTokens())
		{
			String s1=st.nextToken();
			for(i=0;i<s1.length()-1;i++)
			{   
				c=1;
				if(s1.charAt(i)==s1.charAt(i+1))
				{   
					c++;
					for(j=i+2;j<s1.length();j++)
					{
						if(s1.charAt(i)==s1.charAt(j))
							c++;
						else
							break;
					}
				}
				if(c>max)
				{
					max=c;
					i=j-1;
				}
			}
		}
		return (max);
	}
}
