import java.util.Scanner;
import java.util.StringTokenizer;

public class MaxSubstring 
{
	static String extractMax(String str,char c)
	{
		StringTokenizer st=new StringTokenizer(str,c+"");
		String maxstr=st.nextToken(),temp;
		int max=maxstr.length();
		while(st.hasMoreTokens())
		{
			temp=st.nextToken();
			if(temp.length()>max)
			{
				max=temp.length();
				maxstr=new String(temp);
			}
		}
		return maxstr;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String str=in.nextLine();
		char c=in.nextLine().charAt(0);
		System.out.println(MaxSubstring.extractMax(str,c));
	}
}
