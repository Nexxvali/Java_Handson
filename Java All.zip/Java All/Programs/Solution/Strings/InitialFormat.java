import java.util.Scanner;


public class InitialFormat 
{
	static String nameFormatter(String str)
	{	
		return str.replaceAll("(.)(.*) (.*)","$3, $1");
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(InitialFormat.nameFormatter(s));
	}
}
