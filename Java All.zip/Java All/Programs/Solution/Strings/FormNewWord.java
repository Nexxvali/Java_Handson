import java.util.Scanner;

public class FormNewWord 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		int n=in.nextInt();
		System.out.println(FormNewWord.formNewWord(s,n));
	}
	public static String formNewWord(String s,int n)
	{
		int len=s.length();
		if(len>=2*n)
		{
			String s1=s.substring(0,n);
			String s2=s.substring(len-n,len);
			return s1.concat(s2);
		}
		else
			return null;
	}
}
