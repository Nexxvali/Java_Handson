import java.util.Scanner;
import java.util.StringTokenizer;

public class FileExtension 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		System.out.println(FileExtension.fileIdentifier(s));
	}

	public static String fileIdentifier(String s) 
	{
		StringTokenizer st=new StringTokenizer(s,".");
		st.nextToken();
		return st.nextToken();
	}
}
