import java.util.Arrays;
import java.util.Scanner;

public class Anagram 
{
	static int getAnagram(String str1,String str2)
	{
		char []a1=str1.toLowerCase().replaceAll("\\s","").toCharArray();
		char []a2=str2.toLowerCase().replaceAll("\\s","").toCharArray();
		Arrays.sort(a1);
		Arrays.sort(a2);
		if(Arrays.equals(a1,a2))
			return 1;
		return -1;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String str1=in.nextLine();
		String str2=in.nextLine();
		int b=Anagram.getAnagram(str1, str2);
		if(b==1)
			System.out.println("Anagrams");
		else
			System.out.println("Not Anagrams");
	}
}
