import java.util.Scanner;

public class StringEncryption 
{
	static String encrypt(String str)
	{
		StringBuffer s=new StringBuffer();
		int len=str.length(),i=0;
		byte b;
		while(i<len)
		{
			b=(byte)str.charAt(i);
			if((i+1)%2==1)
			{
				if(b=='Z')
					b='A';
				else if(b=='z')
					b='a';
				else
					b++;
			}
			s.append((char)b);
			i++;
		}
		return s.toString();
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(StringEncryption.encrypt(s));
	}
}
