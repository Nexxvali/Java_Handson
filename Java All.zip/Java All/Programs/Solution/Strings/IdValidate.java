import java.util.Scanner;

public class IdValidate 
{
	public static String validateIDLocations(String s,String loc)
	{
		if(s.matches("CTS-[A-Za-z]{3}-[0-9]{4}"))
		{
			if(s.charAt(4)==loc.charAt(0)&&s.charAt(5)==loc.charAt(1)&&s.charAt(6)==loc.charAt(2))
				return "Valid id";
		}
		return "Invalid id";
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		String l=in.nextLine();
		System.out.println(IdValidate.validateIDLocations(s,l));
	}
}