import java.util.Scanner;

public class CheckCharacter 
{
	static int checkCharacters(String str)
	{
		if(str.charAt(0)==str.charAt(str.length()-1))
			return 1;
		else
			return -1;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		if(CheckCharacter.checkCharacters(s)==1)
			System.out.println("Valid");
		else
			System.out.println("Invalid");
	}
}
