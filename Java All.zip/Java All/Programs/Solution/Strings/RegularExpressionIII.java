import java.util.Scanner;


public class RegularExpressionIII 
{
	static int validateString(String s1,String s2)
	{	
		return s1.replaceAll(s2,"\\$").replaceAll("[^$]","").length();
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		String s1=in.nextLine();
		System.out.println(RegularExpressionIII.validateString(s,s1));
	}
}
