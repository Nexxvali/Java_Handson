import java.util.Scanner;


public class MathCalculator 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int a=in.nextInt();
		int b=in.nextInt();
		in.nextLine();
		char o=in.nextLine().charAt(0);
		System.out.println(MathCalculator.calculator(a,b,o));
	}

	public static int calculator(int a,int b,char o) 
	{
		if(o=='+')
			return a+b;
		else if(o=='-')
			return a-b;
		else if(o=='%')
			return a%b;
		else if(o=='*')
			return a*b;
		else if(o=='/')
			return a/b;
		return 0;
	}
}
