import java.util.Scanner;


public class TrimCat 
{
	public static String getAlternateChars(String str)
	{
		String s="";
		for(int i=0;i<str.length();i=i+2)
			s=s.concat(str.charAt(i)+"");
		return s;
	}
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		String str=s.nextLine();
		System.out.println(TrimCat.getAlternateChars(str));
	}
}
