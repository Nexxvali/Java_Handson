import java.util.Scanner;

public class TestVowel 
{
	static int testVowels(String str)
	{
		int i,v1=0,v2=0,v3=0,v4=0,v5=0;
		char c;
		int len=str.length();
		for(i=0;i<len;i++)
		{
			c=str.charAt(i);
			if(c=='a')
				v1++;
			if(c=='e')
				v2++;
			if(c=='i')
				v3++;
			if(c=='o')
				v4++;
			if(c=='u')
				v5++;
		}
		if(v1==1&&v2==1&&v3==1&&v4==1&&v5==1)
			return 1;
		return 2;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		if(TestVowel.testVowels(s)==1)
			System.out.println("yes");
		else
			System.out.println("no");
	}
}
