import java.util.Scanner;


public class ValidateInputPassword 
{
	public static int validatePassword(String s)
	{
		int len=s.length();
		if(len>=8&&s.matches(".*[@_#].*")&&s.matches("^[^@_#0-9].*")&&s.matches(".*[^@_#]$"))
			return 1;
		else
			return -1;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		int b=ValidateInputPassword.validatePassword(s);
		if(b==1)
			System.out.println("Valid");
		else
			System.out.println("Invalid");
	}
}
