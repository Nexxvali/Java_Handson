import java.util.Scanner;

public class UniqueExistCharacter 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		String s1=in.nextLine();
		System.out.println(UniqueExistCharacter.replacePlus(s,s1));
	}

	public static String replacePlus(String s1,String s2) 
	{
		StringBuffer temp=new StringBuffer(s1.replaceAll(".","+"));
		for(int i=0;i<s2.length();i++)
		{
			char c=s2.charAt(i);
			for(int j=0;j<s1.length();j++)
			{
				if((c+"").equalsIgnoreCase(s1.charAt(j)+""))
				{
					temp.deleteCharAt(j);
					temp.insert(j,s1.charAt(j));
				}
			}
		}
		return temp.toString();
	}
}
