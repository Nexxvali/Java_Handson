import java.util.Scanner;

public class UniqueCharacter 
{
	static int uniqueCounter(String s1)
	{	
		int i;
		String s,temp,temp2=new String(s1);
		for(i=0;i<s1.length();i++)
		{
			s=s1.substring(i+1,s1.length());
			temp=s1.charAt(i)+"";
			if(s.contains(temp))
				temp2=temp2.replaceAll(temp,"");
		}
		s1=new String(temp2);
		if(s1.length()>0)
			return s1.length();
		return -1;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(UniqueCharacter.uniqueCounter(s));
	}
}
