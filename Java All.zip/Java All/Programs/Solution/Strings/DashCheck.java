import java.util.Scanner;

public class DashCheck 
{
	static int compareDashes(String s1,String s2)
	{
		int i,j,flag=0;
		for(i=0,j=0;i<s1.length()||j<s2.length();i++,j++)
		{
			if(i==s1.length())
			{
				if(s2.substring(i).contains("-"))
					flag=1;	
				break;
			}
			if(j==s2.length())
			{
				if(s1.substring(j).contains("-"))
					flag=1;	
				break;
			}
			if(s1.charAt(i)=='-')
				if(s1.charAt(i)!=s2.charAt(j))
				{
					flag=1;
					break;
				}
		}
		if(flag==0)
			return 1;
		return 2;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s1=in.nextLine();
		String s2=in.nextLine();
		int b=DashCheck.compareDashes(s1,s2);
		if(b==1)
			System.out.println("Yes");
		else
			System.out.println("No");
	}
}
