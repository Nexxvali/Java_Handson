import java.util.Scanner;

public class WordCountSum 
{
	public static int sumOfDigits(String s[]) 
	{
		int sum=0;
		for(int i=0;i<s.length;i++)
		{
			for(int j=0;j<s[i].length();j++)
			{
				if(s[i].charAt(j)>='0'&&s[i].charAt(j)<='9')
				{
					int n=Integer.parseInt(s[i].charAt(j)+"");
					sum+=n;				
				}
			}
		}
		return sum;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
        int n=Integer.parseInt(in.nextLine());
        String[] a=new String[n];
        for(int i=0;i<n;i++)
        	a[i]=in.nextLine();
        System.out.println(WordCountSum.sumOfDigits(a));
	}
}
