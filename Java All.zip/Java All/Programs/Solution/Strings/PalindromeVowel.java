import java.util.Scanner;

public class PalindromeVowel 
{
	public static int checkPalindrome(String s)
	{
		String srev=new StringBuffer(s).reverse().toString();
		if(s.equals(srev))
		{
			int c=0;
			s=s.toLowerCase();
			if(s.contains("a"))
				c++;
			if(s.contains("e"))
				c++;
			if(s.contains("i"))
				c++;
			if(s.contains("o"))
				c++;
			if(s.contains("u"))
				c++;
			if(c>=2)
				return 1;
		}
		return -1;
	}
	public static void main(String []args)
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		if(PalindromeVowel.checkPalindrome(s)==1)
			System.out.println("Valid");
		else
			System.out.println("Invalid");
	}
}
