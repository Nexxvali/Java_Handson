import java.util.Scanner;
import java.util.StringTokenizer;

public class LastLetter 
{
	static String getLastLetter(String str)
	{
		StringTokenizer st=new StringTokenizer(str);
		String s="",temp;
		while(st.hasMoreTokens())
		{
			temp=st.nextToken();
			s=s.concat((temp.charAt(temp.length()-1)+"").toUpperCase()).concat("$");
		}
		return s.substring(0,s.length()-1);
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String str=in.nextLine();
		System.out.println(LastLetter.getLastLetter(str));
	}
}
