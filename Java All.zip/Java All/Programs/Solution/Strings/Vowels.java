import java.util.Scanner;
import java.util.StringTokenizer;

public class Vowels 
{
	static String storeMaxVowelWord(String str)
	{
		StringTokenizer st=new StringTokenizer(str);
		String max="",temp;
		while(st.hasMoreTokens())
		{
			temp=st.nextToken();
			if(max.replaceAll("[^AEIOUaeiou]","").length()<temp.replaceAll("[^AEIOUaeiou]","").length())
				max=new String(temp);
		}
		return max;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(Vowels.storeMaxVowelWord(s));
	}
}
