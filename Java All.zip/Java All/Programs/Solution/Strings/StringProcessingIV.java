import java.util.Scanner;

public class StringProcessingIV
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		int n=in.nextInt();
		System.out.println(StringProcessingIV.getStringUsingNthCharacter(s,n));
	}

	public static String getStringUsingNthCharacter(String str,int n) 
	{
		StringBuffer sb=new StringBuffer();
		sb.append(str.charAt(0));
		for(int i=1;i<=str.length()/n;i++)
			sb.append(str.charAt(i*n-1));
		return sb.toString();
	}
}
