import java.util.Scanner;

public class CountSequentialCharacter 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		System.out.println(CountSequentialCharacter.countSequentialChars(s));
	}

	public static int countSequentialChars(String s) 
	{
		int len=s.length(),i,count=0;
		s=s.toUpperCase();
		for(i=0;i<len-2;)
		{
			if(s.charAt(i)==s.charAt(i+1)&&s.charAt(i)==s.charAt(i+2))
			{
				count++;
				i=i+3;
			}
			else
				i=i+1;
		}
		return count;
	}
}
