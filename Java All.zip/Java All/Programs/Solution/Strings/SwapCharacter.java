import java.util.Scanner;

public class SwapCharacter 
{
	public static String swapCharacter(String s)
	{
		int i;
		StringBuffer sb=new StringBuffer();
		if(s.length()%2==0)
		{
			for(i=0;i<s.length();i=i+2)
			{
				sb.append(s.charAt(i+1));
				sb.append(s.charAt(i));
			}
		}
		else
		{
			for(i=0;i<s.length()-1;i=i+2)
			{
				sb.append(s.charAt(i+1));
				sb.append(s.charAt(i));
			}
			sb.append(s.charAt(i));
		}
		return sb.toString();
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(SwapCharacter.swapCharacter(s));
	}
}
