import java.util.Scanner;

public class StringRepetition 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		int n=in.nextInt();
		System.out.println(StringRepetition.repeatString(s,n));
	}
	public static String repeatString(String s,int n) 
	{
		if(n==1)
			return s.charAt(0)+"";
		else if(n==2)
			return s.substring(0,2).concat(" ").concat(s.substring(0,2));
		String s1=s.substring(0,3),s2="";
		for(int i=0;i<n;i++)
			s2=s2.concat(s1)+" ";
		return s2.substring(0,s2.length()-1);
	}
}
