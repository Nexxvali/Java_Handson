import java.util.Scanner;
import java.util.StringTokenizer;

public class StringsProcessing 
{
	public static String findFruitName(String s,int n) 
	{
		StringTokenizer st=new StringTokenizer(s,",");
		int len=st.countTokens();
		String temp="";
		if(n<len)
			for(int i=0;i<n;i++)
				temp=st.nextToken();
		else
			for(int i=0;i<len;i++)
				temp=st.nextToken();
		return temp;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		int n=in.nextInt();
		System.out.println(StringsProcessing.findFruitName(s,n));
	}
}
