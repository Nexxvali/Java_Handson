import java.util.Scanner;


public class PhoneNumberValidator 
{
	static int validatePhoneNumber(String str)
	{	
		if(str.matches("[0-9\\-]*"))
		{
			str=str.replace("-","");
			//if(str.length()==10)
			if(str.matches("[0-9]{10}"))
				return 1;
		}
		return 2;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		if(PhoneNumberValidator.validatePhoneNumber(s)==1)
			System.out.println("Valid");
		else
			System.out.println("Invalid");
	}
}
