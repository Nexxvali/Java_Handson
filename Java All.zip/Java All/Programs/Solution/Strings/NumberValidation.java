import java.util.Scanner;

public class NumberValidation 
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		String pan=s.next();
		int b=NumberValidation.validateNumber(pan);
		if(b==1)
			System.out.println("valid Pancard Number");
		else
			System.out.println("not a valid credential");
	}
	public static int validateNumber(String input) 
	{
		int b=0;
		if(input.matches("[0-9]{3}-[0-9]{3}-[0-9]{4}"))
			b=1;
		else
			b=-1;
		return b;
	}
}
