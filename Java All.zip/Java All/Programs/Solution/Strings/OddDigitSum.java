import java.util.Scanner;

public class OddDigitSum
{
	static int oddDigitSum(String s[],int n)
	{	
		int sum=0;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<s[i].length();j++)
			{
				char c=s[i].charAt(j);
				if(c>='0'&&c<='9')
				{
					int num=Integer.parseInt(c+"");
					if(num%2==1)
						sum=sum+num;
				}
			}
		}
		return sum;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		in.nextLine();
		String s[]=new String[n];
		for(int i=0;i<n;i++)
			s[i]=in.nextLine();
		System.out.println(OddDigitSum.oddDigitSum(s,n));
	}
}
