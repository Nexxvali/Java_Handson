import java.util.Scanner;

public class NegativeString 
{
	static String negativeString(String str)
	{	
		return str.replaceAll("^is([ ])|([ ])is$|([ ])is([ ])","$2$3is not$1$4");
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(NegativeString.negativeString(s));
	}
}
