import java.util.Scanner;

public class NameShrink 
{
	static String getFormatedString(String str)
	{	
		return str.replaceAll("(.)(.*) (.)(.*) (.*)","$5 $3.$1");
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(NameShrink.getFormatedString(s));
	}
}