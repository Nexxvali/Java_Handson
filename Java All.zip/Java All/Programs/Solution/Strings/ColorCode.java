import java.util.Scanner;

public class ColorCode 
{
	public static int validateColorCode(String s)
	{
		if(s.matches("#[0-9A-F]{6}"))
			return 1;
		else
			return -1;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		if(ColorCode.validateColorCode(s)==1)
			System.out.println("Valid");
		else
			System.out.println("Invalid");
	}
}