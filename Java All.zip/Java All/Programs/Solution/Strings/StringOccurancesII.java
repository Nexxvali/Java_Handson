import java.util.Scanner;

public class StringOccurancesII 
{
	static int getSubstring(String s1,String s2)
	{	
		s1=s1.replaceAll(s2,"\\$");
		s1=s1.replaceAll("[^$]","");
		return s1.length();
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s1=in.nextLine();
		String s2=in.nextLine();
		System.out.println(StringOccurancesII.getSubstring(s1,s2));
	}
}
