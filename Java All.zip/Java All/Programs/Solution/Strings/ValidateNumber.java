import java.util.Scanner;


public class ValidateNumber 
{
	static String validateNumber(String str)
	{	
		if(str.matches("-[0-9]*"))
			return str.substring(1);
		return "-1";
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(ValidateNumber.validateNumber(s));
	}
}
