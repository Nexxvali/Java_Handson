import java.util.Scanner;

public class PlayingStringI 
{
	public static String formString(String s[],int m)
	{
		String str="";
		for(int i=0;i<s.length;i++)
		{
			if(s[i].length()>=m)
				str=str+s[i].charAt(m-1);
			else
				str=str+"$";
		}
		return str;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
        int n=Integer.parseInt(in.nextLine());
        String[] a=new String[n];
        for(int i=0;i<n;i++)
        	a[i]=in.nextLine();
        int m=in.nextInt();
        System.out.println(PlayingStringI.formString(a,m));
	}
}