import java.util.Scanner;

public class OccuranceCount 
{
	public static int countWords(String s,String s1)
    {
		return s.replaceAll("^"+s1+"[ ]|"+"[ ]"+s1+"$|[ ]"+s1+"[ ]","\\$").replaceAll("[^$]","").length();
    }
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		String s1=in.nextLine();
		System.out.println(OccuranceCount.countWords(s,s1));
	}
}
