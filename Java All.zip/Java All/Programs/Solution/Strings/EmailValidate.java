import java.util.Scanner;

public class EmailValidate
{
	static boolean validateEmail(String str)
	{	
		return str.matches("[a-zA-Z0-9]{3,}@[a-zA-Z]{5,}\\.com");
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println((EmailValidate.validateEmail(s)+"").toUpperCase());
	}
}
