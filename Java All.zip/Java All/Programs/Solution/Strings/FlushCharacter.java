import java.util.Scanner;

public class FlushCharacter 
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		System.out.println(FlushCharacter.getSpecialChar(s));
	}
	public static String getSpecialChar(String s) 
	{
		return s.replaceAll("[a-zA-Z ]","");
	}
}
