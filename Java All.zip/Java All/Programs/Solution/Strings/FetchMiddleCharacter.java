import java.util.Scanner;

public class FetchMiddleCharacter 
{
	static String getMiddleCharspresent(String str)
	{
		int len=str.length();
		String s=str.charAt(len/2-1)+""+str.charAt(len/2)+"";
		return s;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		System.out.println(FetchMiddleCharacter.getMiddleCharspresent(s));
	}
}
