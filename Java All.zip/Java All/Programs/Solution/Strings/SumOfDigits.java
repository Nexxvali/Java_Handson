import java.util.Scanner;


public class SumOfDigits 
{
	public static int getvalues(String s) 
	{
		int sum=0,len=s.length(),i;
		for(i=0;i<len;i++)
		{
			if(s.charAt(i)>='0'&&s.charAt(i)<='9')
			{
				int n=Integer.parseInt(s.charAt(i)+"");
				sum+=n;				
			}
		}
		if(sum==0)
			return -1;
		else
			return sum;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(SumOfDigits.getvalues(s));
	}
}
