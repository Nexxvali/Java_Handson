import java.util.Scanner;

public class RepeatFront 
{
	static String repeatFirstThreeCharacters(String str,int n)
	{	
		String s="";
		if(str.length()<3)
		{
			for(int i=0;i<n;i++)
				s=s+str;
			return s;
		}
		for(int i=0;i<n;i++)
			s=s+str.substring(0,3);
		return s;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		int n=in.nextInt();
		System.out.println(RepeatFront.repeatFirstThreeCharacters(s,n));
	}
}
