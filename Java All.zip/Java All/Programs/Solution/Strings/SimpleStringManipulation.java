import java.util.Scanner;

public class SimpleStringManipulation 
{
	static String getString(String s)
	{
		StringBuffer sb=new StringBuffer(s);
		if(s.charAt(0)!='j')
			sb.deleteCharAt(0);
		if(s.charAt(1)!='b')
			sb.deleteCharAt(1);
		return sb.toString();
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String str=in.next();
		System.out.println(SimpleStringManipulation.getString(str));
	}
}
