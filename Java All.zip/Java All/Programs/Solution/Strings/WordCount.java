import java.util.Scanner;

public class WordCount 
{
	public static int countWord(String s[],int m)
	{
		int count=0;
		for(int i=0;i<s.length;i++)
			if(s[i].length()==m)
				count++;
		return count;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
        int n=Integer.parseInt(in.nextLine());
        String[] s=new String[n];
        for(int i=0;i<n;i++)
        	s[i]=in.nextLine();
        int m=in.nextInt();
        System.out.println(WordCount.countWord(s,m));
	}
}
