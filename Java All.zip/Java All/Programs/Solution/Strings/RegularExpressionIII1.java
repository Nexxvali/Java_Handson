import java.util.Scanner;

public class RegularExpressionIII1 
{
	static int passwordValidation(String s)
	{	
		if(s.length()>=8&&s.matches(".*[A-Z].*")&&s.matches(".*[a-z].*")&&s.matches(".*[0-9].*")&&s.matches(".*[^0-9A-Za-z].*"))
			return 1;
		return -1;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		int b=RegularExpressionIII1.passwordValidation(s);
		if(b==1)
			System.out.println("valid");
		else
			System.out.println("invalid");
	}
}
