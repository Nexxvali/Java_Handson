import java.util.Scanner;

public class GenerateSeries 
{
	public static int addSeries(int n)
	{
		int sum=1,i=3;
		for(int j=0;i<=n;j++)
		{
			if(j%2==0)
				sum=sum+i;
			else
				sum=sum-i;
			i=i+2;
		}
		return sum;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		System.out.println(addSeries(n));
	}
}
