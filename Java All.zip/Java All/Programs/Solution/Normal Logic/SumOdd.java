import java.util.Scanner;


public class SumOdd
{
	public static int addOddNumbers(int n)
	{
		int sum=0;
		for(int i=1;i<=n;i++)
			if(i%2==1)
				sum=sum+i;
		return sum;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		System.out.println(addOddNumbers(n));
	}
}
