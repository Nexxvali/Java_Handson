import java.util.Scanner;


public class CommonElements 
{
	public static int sumCommonElements(Integer ar1[],Integer ar2[])
	{
		int sum=0;
		for(int i=0;i<ar1.length;i++)
			for(int j=0;j<ar2.length;j++)
				if(ar1[i]==ar2[j])
					sum=sum+ar1[i];
		return sum;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		Integer ar1[]=new Integer[n];
		for(int i=0;i<n;i++)
			ar1[i]=in.nextInt();
		Integer ar2[]=new Integer[n];
		for(int i=0;i<n;i++)
			ar2[i]=in.nextInt();
		int res=sumCommonElements(ar1,ar2);
		if(res==-1)
			System.out.println("No common elements");
		else
			System.out.println(res);
	}
}
