import java.util.Scanner;

public class SumMaxMin 
{
		public static int getSumMaxMin(int a,int b,int c)
		{
			int max=Integer.max(a,Integer.max(b,c));
			int min=Integer.min(a,Integer.min(b,c));
			return max+min;
		}
		public static void main(String args[])
		{
			Scanner in=new Scanner(System.in);
			int a=in.nextInt();
			int b=in.nextInt();
			int c=in.nextInt();
			System.out.println(getSumMaxMin(a,b,c));
		}
}
