import java.util.ArrayList;
import java.util.Scanner;

public class Remove10 
{
	public static Integer[] removeTens(int ar[])
	{
		ArrayList<Integer> l=new ArrayList<Integer>();
		for(int i=0,j=0;i<ar.length;i++)
			if(ar[i]!=10)
				l.add(ar[i]);
		Integer a[]=new Integer[l.size()];
		l.toArray(a);
		return a;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
		int ar[]=new int[n];
		for(int i=0;i<n;i++)
			ar[i]=in.nextInt();
		for(int i:removeTens(ar))
			System.out.println(i);
	}
}
