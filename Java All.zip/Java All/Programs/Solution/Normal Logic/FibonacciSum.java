import java.util.Scanner;


public class FibonacciSum 
{
	public static int getSumOfNfibos(int n)
	{
		int sum=0,a=-1,b=1,c;
		for(int i=0;i<n;i++)
		{
			c=a+b;
			a=b;
			b=c;
			sum=sum+c;
		}
		return sum;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		System.out.println(getSumOfNfibos(n));
	}
}
