import java.util.Arrays;
import java.util.Scanner;

public class MedianCalculation 
{
	public static int calculateMedian(int ar[])
	{
		Arrays.sort(ar);
		if(ar.length%2==1)
			return ar[ar.length/2];
		return (int)Math.round((ar[ar.length/2-1]+ar[ar.length/2])/(float)2);
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int ar[]=new int[n];
		for(int i=0;i<n;i++)
			ar[i]=in.nextInt();
		System.out.println(calculateMedian(ar));
	}
}
