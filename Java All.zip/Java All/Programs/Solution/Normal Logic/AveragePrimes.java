import java.util.Scanner;

public class AveragePrimes 
{
	public static float addPrimeIndex(int ar[])
	{
		int prime[]=new int[]{2,3,5,7,11,13,17,19};
		int j=0,sum=0;
		for(int i=prime[j++];i<ar.length;i=prime[j++])
			sum=sum+ar[i];
		return Math.round(sum/(float)(j-1)*100.f)/100.0f;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int ar[]=new int[n];
		for(int i=0;i<n;i++)
			ar[i]=in.nextInt();
		System.out.println(addPrimeIndex(ar));
	}
}
