import java.util.Scanner;


public class SumSquaresDigits
{
	public static int getDigitSum(int n)
	{
		int sum=0,t;
		while(n>0)
		{
			t=n%10;
			sum=sum+t*t;
			n=n/10;
		}
		return sum;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		System.out.println(getDigitSum(n));
	}
}
