import java.util.Scanner;

public class KaprekarNumber 
{
	public static int getKaprekarNumber(int n)
	{
		int num=n,count=0,rem,quo,square=n*n;
		while(num>0)
		{
			count++;
			num=num/10;
		}
		rem = square % ((int) Math.pow(10, count));
        quo = square / ((int) Math.pow(10, count));
        if(rem+quo==n)
        	return 1;
        return -1;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		if(getKaprekarNumber(n)==1)
			System.out.println("Kaprekar Number");
		else
			System.out.println("Not A Kaprekar Number");
	}
}
