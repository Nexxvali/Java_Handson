import java.util.Scanner;


public class DigitComparison 
{
	public static boolean sumOfSquaresOfEvenDigits(int a,int b)
	{
		return (a%10==b%10);
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int a=in.nextInt();
		int b=in.nextInt();
		System.out.println(sumOfSquaresOfEvenDigits(a,b));
	}
}
