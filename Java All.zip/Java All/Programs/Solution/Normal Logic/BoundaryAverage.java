import java.util.Arrays;
import java.util.Scanner;

public class BoundaryAverage 
{
	public static float sumOfSquaresOfEvenDigits(int a[])
	{
		int sum=0;
		Arrays.sort(a);
		sum=a[0]+a[a.length-1];
		return sum/(float)2;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=in.nextInt();
		System.out.println(sumOfSquaresOfEvenDigits(a));
	}
}
