import java.util.Arrays;
import java.util.Scanner;


public class AddReverse
{
	public static int addAndReverse(int ar[],int num)
	{
		Arrays.sort(ar);
		int index=Arrays.binarySearch(ar,num);
		int sum=0;
		for(int i=index+1;i<ar.length;i++)
			sum=sum+ar[i];
		return Integer.parseInt(new StringBuffer(String.valueOf(sum)).reverse().toString());
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int ar[]=new int[n];
		for(int i=0;i<n;i++)
			ar[i]=in.nextInt();
		int num=in.nextInt();
		System.out.println(addAndReverse(ar,num));
	}
}
