import java.util.Scanner;


public class EvenOddIndexSum 
{
	public static boolean sumOfOddEvenPositioned(int n)
	{
		int se=0,so=0,i=0;
		while(n>0)
		{
			if(i%2==0)
				se=se+n%10;
			else
				so=so+n%10;
			n=n/10;
			i++;
		}
		if(se==so)
			return true;
		return false;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		System.out.println(sumOfOddEvenPositioned(n));
	}
}
