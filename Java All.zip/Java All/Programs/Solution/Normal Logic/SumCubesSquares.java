import java.util.Scanner;

public class SumCubesSquares 
{
	public static int addEvenOdd(int a[])
	{
		int sum=0;
		for(int i=0;i<a.length;i++)
			if(a[i]%2==0)
				sum=sum+a[i]*a[i];
			else
				sum=sum+a[i]*a[i]*a[i];
		return sum;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int ar[]=new int[n];
		for(int i=0;i<n;i++)
			ar[i]=in.nextInt();
		System.out.println(addEvenOdd(ar));
	}
}
