import java.util.ArrayList;
import java.util.Scanner;

public class MaxAdmissions 
{
	public static int getYear(ArrayList<Integer> l1)
	{
		int maxad=l1.get(1),maxyr=l1.get(0);
		for(int i=2;i<l1.size();i=i+2)
		{
			int ad=l1.get(i+1),yr=l1.get(i);
			if(maxad<ad)
			{
				maxad=ad;
				maxyr=yr;
			}
		}
		return maxyr;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		ArrayList<Integer> l1=new ArrayList<Integer>();
		for(int i=0;i<2*n;i++)
			l1.add(in.nextInt());
		System.out.println(getYear(l1));
	}
}
