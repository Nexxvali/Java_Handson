import java.util.Scanner;


public class PalindromeRange 
{
	public static int addPalindromes(int a,int b)
	{
		int n=a,sum=0;
		while(n<=b)
		{
			String s=String.valueOf(n);
			String sr=new StringBuffer(s).reverse().toString();
			if(s.equals(sr))
				sum=sum+n;
			n++;
		}
		return sum;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int a=in.nextInt();
		int b=in.nextInt();
		System.out.println(addPalindromes(a,b));
	}
}
