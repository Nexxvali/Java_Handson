import java.util.Scanner;

public class SumNonPrimeNumbers 
{
	public static int addNumbers(int n)
	{
		int sum=1;
		for(int i=4;i<=n;i++)
		{
			int flag=0;
			for(int j=2;j<i;j++)
				if(i%j==0)
				{
					flag=1;
					break;
				}
			if(flag==1)
				sum=sum+i;
		}
		return sum;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		System.out.println(addNumbers(n));
	}
}
