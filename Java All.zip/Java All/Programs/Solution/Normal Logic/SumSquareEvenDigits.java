import java.util.Scanner;


public class SumSquareEvenDigits 
{
	public static int sumOfSquaresOfEvenDigits(int n)
	{
		int sum=0,temp;
		while(n>0)
		{
			temp=n%10;
			if(temp%2==0)
				sum=sum+temp*temp;
			n=n/10;
		}
		return sum;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		System.out.println(sumOfSquaresOfEvenDigits(n));
	}
}
