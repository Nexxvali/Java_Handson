import java.util.Scanner;


public class Duplicates 
{
	public static int sumOfSquaresOfEvenDigits(int a,int b,int c)
	{
		int sum=a+b+c;
		if(a==b)
			sum=sum-a-b;
		else if(b==c)
			sum=sum-b-c;
		else if(a==c)
			sum=sum-a-c;
		return sum;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int a=in.nextInt();
		int b=in.nextInt();
		int c=in.nextInt();
		System.out.println(sumOfSquaresOfEvenDigits(a,b,c));
	}
}
