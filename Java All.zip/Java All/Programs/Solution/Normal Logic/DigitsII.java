import java.util.Scanner;

public class DigitsII 
{
	public static int getDigitSum(int n)
	{
		while(n>10)
		{
			int r,sum=0;
			while(n>0)
			{
				r=n%10;
				sum=sum+r;
				n=n/10;
			}
			n=sum;
		}
		return n;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		System.out.println(getDigitSum(n));
	}
}
