import java.util.Scanner;

public class LargestDifference 
{
	public static int checkDifference(int ar[])
	{
		int maxdiff=0,maxi=0;
		for(int i=0;i<ar.length-1;i++)
			if(Math.abs(ar[i]-ar[i+1])>maxdiff)
			{
				maxdiff=Math.abs(ar[i]-ar[i+1]);
				if(ar[i]>ar[i+1])
					maxi=i;
				else
					maxi=i+1;
			}
		return maxi;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int ar[]=new int[n];
		for(int i=0;i<n;i++)
			ar[i]=in.nextInt();
		System.out.println(checkDifference(ar));
	}
}
