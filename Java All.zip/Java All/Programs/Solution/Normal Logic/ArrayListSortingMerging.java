import java.util.*;


public class ArrayListSortingMerging 
{
	public static ArrayList<Integer> sortMergedArrayList(ArrayList<Integer> l1,ArrayList<Integer> l2)
	{
		ArrayList<Integer> l3=new ArrayList<Integer>();
		l3.addAll(l1);
		l3.addAll(l2);
		Collections.sort(l3);
		ArrayList<Integer> res=new ArrayList<Integer>();
		res.add(l3.get(2));
		res.add(l3.get(6));
		res.add(l3.get(8));
		return res;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		ArrayList<Integer> l1=new ArrayList<Integer>();
		for(int i=0;i<5;i++)
			l1.add(in.nextInt());
		ArrayList<Integer> l2=new ArrayList<Integer>();
		for(int i=0;i<5;i++)
			l2.add(in.nextInt());
		for(Integer i:sortMergedArrayList(l1,l2))
			System.out.println(i);
	}
}
