import java.util.Scanner;

public class nCr 
{
	public static int calculateNcr(int n,int r)
	{
		int f1=1,f2=1,f3=1;
		for(int i=n;i>1;i--)
			f1=f1*i;
		for(int i=r;i>1;i--)
			f2=f2*i;
		for(int i=n-r;i>1;i--)
			f3=f3*i;
		return f1/(f2*f3);
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int r=in.nextInt();
		System.out.println(calculateNcr(n,r));
	}
}
