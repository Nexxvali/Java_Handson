import java.util.Scanner;

public class Scores 
{
	public static boolean checkScores(int ar[])
	{
		for(int i=0;i<ar.length-1;i++)
			if(ar[i]==100&&ar[i+1]==100)
				return true;
		return false;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int ar[]=new int[n];
		for(int i=0;i<n;i++)
			ar[i]=in.nextInt();
		System.out.println(checkScores(ar));
	}
}
