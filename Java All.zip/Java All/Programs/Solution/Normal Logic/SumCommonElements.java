import java.util.Scanner;

public class SumCommonElements 
{
	public static int getSumOfIntersection(Integer ar1[],Integer ar2[])
	{
		int c1=-1,c2=-1;
		for(int i=0;i<ar1.length;i++)
			for(int j=0;j<ar1.length;j++)
				if(ar1[i]==ar1[j]&&i!=j)
				{
					c1=ar1[i];
					break;
				}
		for(int i=0;i<ar2.length;i++)
			for(int j=0;j<ar2.length;j++)
				if(ar2[i]==ar2[j]&&i!=j)
				{
					c2=ar2[i];
					break;
				}
		if(c1!=-1&&c2!=-1)
			return c1+c2;
		return -1;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		Integer ar1[]=new Integer[n];
		for(int i=0;i<n;i++)
			ar1[i]=in.nextInt();
		Integer ar2[]=new Integer[n];
		for(int i=0;i<n;i++)
			ar2[i]=in.nextInt();
		int res=getSumOfIntersection(ar1,ar2);
		if(res==-1)
			System.out.println("No common elements");
		else
			System.out.println(res);
	}
}
