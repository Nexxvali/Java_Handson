import java.util.Scanner;

public class CheckSumOddDigits 
{
	public static int checkSum(int n)
	{
		int sum=0,temp;
		while(n>0)
		{
			temp=n%10;
			sum=sum+temp;
			n=n/10;
		}
		if(sum%2==0)
			return -1;
		return 1;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		if(checkSum(n)==1)
			System.out.println("Sum of odd digits is odd.");
		else
			System.out.println("Sum of odd digits is even.");
	}
}
