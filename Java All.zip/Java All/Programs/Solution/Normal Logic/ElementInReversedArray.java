import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;


public class ElementInReversedArray 
{
	public static int getElementPosition(String ar[],String search)
	{
		/*Arrays.sort(ar);
		int index=Arrays.binarySearch(ar,search);
		return ar.length-1-index+1;*/
		int index=0;
		Arrays.sort(ar,Collections.reverseOrder());
		for(int i=0;i<ar.length;i++)
		{
			if(ar[i].equals(search))
				index=i+1;
		}
		return index;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
		String ar[]=new String[n];
		for(int i=0;i<n;i++)
			ar[i]=in.nextLine();
		String search=in.nextLine();
		System.out.println(getElementPosition(ar,search));
	}
}
