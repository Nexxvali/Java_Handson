import java.util.Scanner;

public class DecimalBinary 
{
	public static long convertDecimalToBinary(int n)
	{
		return Long.parseLong(Integer.toBinaryString(n));
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		System.out.println(convertDecimalToBinary(n));
	}
}
