import java.util.Scanner;


public class UniqueNumber
{
	public static int getUnique(int n)
	{
		String s=Integer.toString(n);
        int l=s.length(),flag=1;
        for(int i=0;i<l-1;i++)
        	for(int j=i+1;j<l;j++)
        		if(s.charAt(i)==s.charAt(j))
                {
                	flag=-1;
                    break;
                }
        return flag;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int res=getUnique(n);
		if(res==1)
			System.out.println("Unique");
		else
			System.out.println("Not Unique");
	}
}
