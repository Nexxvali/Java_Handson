import java.util.Scanner;

public class ShiftLeft 
{
	public static int[] getBigDiff(int a[])
	{
		int r[]=new int[a.length];
		for(int i=0,j=0;i<a.length;i++)
			if(a[i]!=5)
				r[j++]=a[i];
		return r;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int ar[]=new int[n];
		for(int i=0;i<n;i++)
			ar[i]=in.nextInt();
		for(int i:getBigDiff(ar))
			System.out.println(i);
	}

}
