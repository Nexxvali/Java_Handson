import java.util.Scanner;


public class UniqueInteger 
{
	public static int calculateUnique(int a,int b,int c)
	{
		if(a==b&&a==c)
			return 1;
		else if(a==b||a==c||b==c)
			return 2;
		return 3;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int a=in.nextInt();
		int b=in.nextInt();
		int c=in.nextInt();
		System.out.println(calculateUnique(a,b,c));
	}
}
