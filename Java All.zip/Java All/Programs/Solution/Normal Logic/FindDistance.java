import java.util.Scanner;

public class FindDistance
{
	public static int sumOfSquaresOfEvenDigits(int x1,int y1,int x2,int y2)
	{
		int dx=x1-x2,dy=y1-y2;
		return (int)Math.round(Math.sqrt(dx*dx+dy*dy));
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int x1=in.nextInt();
		int y1=in.nextInt();
		int x2=in.nextInt();
		int y2=in.nextInt();
		System.out.println(sumOfSquaresOfEvenDigits(x1,y1,x2,y2));
	}
}
