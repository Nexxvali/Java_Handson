import java.util.ArrayList;
import java.util.Scanner;


public class ArrayListToStringArray1
{
	public static String[] fruitSelector(ArrayList<String> l,ArrayList<String> l1)
	{
		ArrayList<String> res=new ArrayList<String>();
		for(String i:l)
		{
			if(!((i.charAt(i.length()-1)+"").toUpperCase().equals("A")||(i.charAt(i.length()-1)+"").toUpperCase().equals("E")))
				res.add(i);
		}
		for(String i:l1)
		{
			if(!((i.charAt(0)+"").toUpperCase().equals("M")||(i.charAt(0)+"").toUpperCase().equals("A")))
				res.add(i);
		}
		String []s=new String[res.size()];
		res.toArray(s);
		return s;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        ArrayList<String> l=new ArrayList<String>();
        for(int i=0;i<n;i++)
        	l.add(in.nextLine());
        n=Integer.parseInt(in.nextLine());
        ArrayList<String> l1=new ArrayList<String>();
        for(int i=0;i<n;i++)
        	l1.add(in.nextLine());
        String ss[]=ArrayListToStringArray1.fruitSelector(l,l1);
        if(ss.length==0)
        	System.out.println("No fruit found");
        else
        	for(String s:ss)
        		System.out.println(s);
	}
}