import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListToStringArray 
{
	public static String[] convertToStringArray(ArrayList<String> l)
	{
		String s[]=new String[l.size()];
		l.toArray(s);
		return s;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        ArrayList<String> l=new ArrayList<String>();
        for(int i=0;i<n;i++)
        	l.add(in.next());
        for(String s:ArrayListToStringArray.convertToStringArray(l))
        	System.out.println(s);
	}
} 