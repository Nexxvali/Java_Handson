import java.util.*;

public class DuplicateCharacters 
{
	static String removeDuplicates(String str)
	{	
		LinkedHashSet<Character> l=new LinkedHashSet<Character>();
		char[] c=str.toCharArray();
		for(int i=0;i<c.length;i++)
			l.add(c[i]);
		Character[] C=new Character[l.size()];
		l.toArray(C);
		String s="";
		for(Character i:C)
			s=s+i;
		return s;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		System.out.println(DuplicateCharacters.removeDuplicates(s));
	}
}
