import java.util.*;

public class MasteringHashmap 
{
	public static int getAverageOfOdd(HashMap<Integer,Integer>hm)
	{
		int sum=0,count=0;
		for(Map.Entry<Integer, Integer> map:hm.entrySet())
		{
			if(map.getKey()%2==1)
			{
				sum=sum+map.getValue();
				count++;
			}
		}
		return sum/count;
	}
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		int s=Integer.parseInt(sc.nextLine());
		HashMap<Integer,Integer>hm=new HashMap<Integer,Integer>();
		for(int i=0;i<s;i++)
			hm.put(Integer.parseInt(sc.nextLine()),Integer.parseInt(sc.nextLine()));
		System.out.println(MasteringHashmap.getAverageOfOdd(hm));
	}
}
