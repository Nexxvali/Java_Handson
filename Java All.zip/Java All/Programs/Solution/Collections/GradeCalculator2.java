import java.util.*;

public class GradeCalculator2 
{
	public static TreeMap<Integer,String> calculateGrade(HashMap<Integer,Integer> h1)
	{
		TreeMap<Integer,String> t=new TreeMap<Integer,String>();
		for(Map.Entry<Integer,Integer> map:h1.entrySet())
		{
			if(map.getValue()>=80)
				t.put(map.getKey(),"GOLD");
			else if(map.getValue()>=60)
				t.put(map.getKey(),"SILVER");
			else if(map.getValue()>=45)
				t.put(map.getKey(),"BRONZE");
			else
				t.put(map.getKey(),"FAIL");
		}
		return t;
	}
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		int s=sc.nextInt();
		HashMap<Integer,Integer>hm=new HashMap<Integer,Integer>();
		for(int i=0;i<s;i++)
			hm.put(sc.nextInt(),sc.nextInt());
		for(Map.Entry<Integer,String> map:GradeCalculator2.calculateGrade(hm).entrySet())
			System.out.println(map.getKey()+"\n"+map.getValue());
	}
}
