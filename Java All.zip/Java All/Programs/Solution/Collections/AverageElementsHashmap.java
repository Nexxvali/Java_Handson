import java.util.HashMap;
import java.util.Scanner;

public class AverageElementsHashmap 
{
	public static float avgOfEven(HashMap<Integer,Float> h)
	{
		float avg=0.0f;
		int count=0;
		for(Integer i:h.keySet())
			if(i%2==0)
			{
				avg=avg+h.get(i);
				count++;
			}
		return Math.round((avg/count)*100.0f)/100.0f;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        HashMap<Integer,Float> h=new HashMap<Integer,Float>();
        for(int i=0;i<n;i++)
        	h.put(in.nextInt(),in.nextFloat());
        System.out.println(AverageElementsHashmap.avgOfEven(h));
	}
}
