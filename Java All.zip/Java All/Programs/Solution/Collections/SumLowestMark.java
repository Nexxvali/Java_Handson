import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class SumLowestMark 
{
	public static int getLowest(HashMap<Integer,Integer> h)
	{
		int sum=0;
		Collection<Integer> c=h.values();
		List<Integer> l=new ArrayList<Integer>(c);
		Collections.sort(l);
		sum=l.get(0)+l.get(1)+l.get(2);
		return sum;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        HashMap<Integer,Integer> h=new HashMap<Integer,Integer>();
        for(int i=0;i<n;i++)
        	h.put(in.nextInt(),in.nextInt());
        System.out.println(SumLowestMark.getLowest(h));
	}
}
