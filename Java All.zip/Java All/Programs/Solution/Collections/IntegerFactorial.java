import java.util.*;

public class IntegerFactorial 
{
	public static LinkedHashMap<Integer,Integer> getFactorial(Integer []n)
	{
		LinkedHashMap<Integer,Integer> h=new LinkedHashMap<Integer,Integer>();
		for(int i=0;i<n.length;i++)
		{
			int fact=1;
			for(int j=n[i];j>0;j--)
				fact=fact*j;
			h.put(n[i],fact);
		}
		return h;
	}
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Integer []a=new Integer[n];
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		for(Map.Entry<Integer, Integer> map:IntegerFactorial.getFactorial(a).entrySet())
			System.out.println(map.getKey()+":"+map.getValue());
	}
}
