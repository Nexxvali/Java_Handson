import java.util.*;

public class UniqueEvenSum 
{
	public static int addUniqueEven(Integer a[])
	{
		HashSet<Integer> h=new HashSet<Integer>(Arrays.asList(a));
		Integer s1[]=new Integer[h.size()];
		h.toArray(s1);
		int sum=0;
		for(int i=0;i<s1.length;i++)
		{	
			if(s1[i]%2==0)
				sum+=s1[i];
		}
		if(sum==0)
			return -1;
		return sum;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
        int n=Integer.parseInt(in.nextLine());
        Integer[] a1=new Integer[n];
        for(int i=0;i<n;i++)
        	a1[i]=in.nextInt();
        int res=UniqueEvenSum.addUniqueEven(a1);
        if(res==-1)
        	System.out.println("no even numbers");
        else
        	System.out.println(res);
	}
}
