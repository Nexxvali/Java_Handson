import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class EmployeeDesignation 
{
	public static ArrayList<String> obtainDesignation(HashMap<String,String> h,String search)
	{
		ArrayList<String> l=new ArrayList<String>();
		for(Map.Entry<String,String> map:h.entrySet())
			if(map.getValue().equals(search))
				l.add(map.getKey());
		Collections.sort(l);
		return l;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        HashMap<String,String> h=new HashMap<String,String>();
        for(int i=0;i<n;i++)
        	h.put(in.next(),in.next());
        String search=in.next();
        for(String s:EmployeeDesignation.obtainDesignation(h,search))
        	System.out.println(s);
	}
}
