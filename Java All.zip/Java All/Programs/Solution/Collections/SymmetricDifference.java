import java.util.*;

public class SymmetricDifference 
{
	public static Integer[] getSymmetricDifference(Integer s1[],Integer s2[])
	{
		Set<Integer> set1=new HashSet<Integer>(Arrays.asList(s1));
		Set<Integer> set2=new HashSet<Integer>(Arrays.asList(s2));
		Set<Integer> union=new HashSet<Integer>();
		union.addAll(set1);
		union.addAll(set2);
		Set<Integer> inter=new HashSet<Integer>(set1);
		inter.retainAll(set2);
		Set<Integer> symdiff=new HashSet<Integer>(union);
		symdiff.removeAll(inter);
		Integer res[]=new Integer[symdiff.size()];
		symdiff.toArray(res);
		Arrays.sort(res);
		return res;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        Integer s1[]=new Integer[n];
        for(int i=0;i<n;i++)
        	s1[i]=Integer.parseInt(in.nextLine());
        n=Integer.parseInt(in.nextLine());
        Integer s2[]=new Integer[n];
        for(int i=0;i<n;i++)
        	s2[i]=Integer.parseInt(in.nextLine());
        for(Integer i:SymmetricDifference.getSymmetricDifference(s1,s2))
        	System.out.println(i);
	}
}
