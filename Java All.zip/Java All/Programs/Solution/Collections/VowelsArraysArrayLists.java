import java.util.ArrayList;
import java.util.Scanner;

public class VowelsArraysArrayLists 
{
	public static boolean isVowel(char c)
	{
		if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
			return true;
		return false;
	}
	public static ArrayList<String> matchCharacter(String[] s)
	{
		ArrayList<String> a=new ArrayList<String>();
		for(int i=0;i<s.length;i++)
			if(isVowel(s[i].charAt(0))&&isVowel(s[i].charAt(s[i].length()-1)))
				a.add(s[i]);
		return a;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        String[] a=new String[n];
        for(int i=0;i<n;i++)
        	a[i]=in.nextLine();
        for(String s:VowelsArraysArrayLists.matchCharacter(a))
        	System.out.println(s);
	}
}
