import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;


public class LastDayOfMonth 
{
	public static int getLastDayOfMonth(String d1)
	{
		SimpleDateFormat f;
		if(d1.matches("[0-9]{2}-[0-9]{2}-[0-9]{4}"))
			f=new SimpleDateFormat("dd-MM-yyyy");
		else
			return -1;
		f.setLenient(false);
		try
		{
			Date d=f.parse(d1);
			Calendar c=Calendar.getInstance();
			c.setTime(d);
			return c.getActualMaximum(Calendar.DAY_OF_MONTH);
		}
		catch(Exception e)
		{
			return -1;
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String d1=in.nextLine();
		System.out.println(LastDayOfMonth.getLastDayOfMonth(d1));
	}
}
