import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class ValidateTime 
{
	public static int validateTime(String s)
	{
		SimpleDateFormat f=new SimpleDateFormat("hh:mm a");
		f.setLenient(false);
		try
		{
			Date d=f.parse(s);
			return 1;
		}
		catch(Exception e)
		{
			return -1;
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String s=in.nextLine();
		if(ValidateTime.validateTime(s)==1)
			System.out.println("valid");
		else
			System.out.println("invalid");
	}
}
