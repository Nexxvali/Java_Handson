import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class MonthName 
{
	public static String getMonthName(String d1)
	{
		SimpleDateFormat f;
		if(d1.matches("[0-9]{2}-[0-9]{2}-[0-9]{2}"))
			f=new SimpleDateFormat("dd-MM-yy");
		else
			return "";
		f.setLenient(false);
		try
		{
			Date d=f.parse(d1);
			f=new SimpleDateFormat("MMMM");
			return f.format(d).toUpperCase();
		}
		catch(Exception e)
		{
			return "";
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String d1=in.nextLine();
		System.out.println(MonthName.getMonthName(d1));
	}
}
