import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class DayOfBirth
{
	public static String calculateBornDay(String d1)
	{
		SimpleDateFormat f;
		if(d1.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}"))
			f=new SimpleDateFormat("yyyy-MM-dd");
		else
			return "";
		f.setLenient(false);
		try
		{
			Date d=f.parse(d1);
			f=new SimpleDateFormat("EEEE");
			return f.format(d).toUpperCase();
		}
		catch(Exception e)
		{
			return "";
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String d1=in.nextLine();
		System.out.println(DayOfBirth.calculateBornDay(d1));
	}
}
