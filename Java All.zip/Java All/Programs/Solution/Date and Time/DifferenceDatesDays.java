import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;


public class DifferenceDatesDays 
{
	public static int getDateDifference(String d1,String d2)
	{
		SimpleDateFormat f;
		if(d1.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")&&d2.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}"))
			f=new SimpleDateFormat("yyyy-MM-dd");
		else
			return -1;
		f.setLenient(false);
		try
		{
			Calendar date=Calendar.getInstance();
			date.setTime(f.parse(d1));
			long day1=date.getTimeInMillis();
			date.setTime(f.parse(d2));
			long day2=date.getTimeInMillis();
			long diff=Math.abs(day2-day1)/(long)(1000*60*60*24);
			return (int)diff;
		}
		catch(Exception e)
		{
			return -1;
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String d1=in.nextLine();
		String d2=in.nextLine();
		System.out.println(DifferenceDatesDays.getDateDifference(d1,d2));
	}
}
