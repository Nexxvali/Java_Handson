import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;


public class LeapYear 
{
	public static boolean isLeapYear(String s) 
	{
		SimpleDateFormat f;
		if(s.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}"))
			f=new SimpleDateFormat("dd/MM/yyyy");
		else
			return false;
		f.setLenient(false);
		try
		{
			Date d=f.parse(s);
			GregorianCalendar cal=new GregorianCalendar();
			cal.setTime(d);
			return cal.isLeapYear(cal.get(Calendar.YEAR));
		}
		catch(Exception e)
		{
			return false;
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String d1=in.nextLine();
		System.out.println(LeapYear.isLeapYear(d1));
	}
}
