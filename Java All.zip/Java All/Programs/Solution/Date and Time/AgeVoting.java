import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;


public class AgeVoting 
{
	public static String getAge(String d1)
	{
		String d2="01/01/2015";
		SimpleDateFormat f;
		if(d1.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}")&&d2.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}"))
			f=new SimpleDateFormat("dd/MM/yyyy");
		else
			return "not-eligible";
		f.setLenient(false);
		try
		{
			Calendar date=Calendar.getInstance();
			date.setTime(f.parse(d1));
			int year1=date.get(Calendar.YEAR);
			date.setTime(f.parse(d2));
			int year2=date.get(Calendar.YEAR);
			int diff=Math.abs(year2-year1);
			if(diff>=18)
				return "eligible";
			else
				return "not-eligible";
		}
		catch(Exception e)
		{
			return "not-eligible";
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String d1=in.nextLine();
		System.out.println(AgeVoting.getAge(d1));
	}
}
