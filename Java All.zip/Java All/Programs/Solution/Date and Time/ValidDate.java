import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class ValidDate 
{
	public static int validateDate(String s)
	{
		SimpleDateFormat f;
		if(s.matches("[0-9]{2}\\.[0-9]{2}\\.[0-9]{4}"))
			f=new SimpleDateFormat("dd.MM.yyyy");
		else if(s.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}"))
			f=new SimpleDateFormat("dd/MM/yyyy");
		else if(s.matches("[0-9]{2}-[0-9]{2}-[0-9]{4}"))
			f=new SimpleDateFormat("dd-MM-yyyy");
		else
			return -1;
		f.setLenient(false);
		try
		{
			Date d=f.parse(s);
			return 1;
		}
		catch(Exception e)
		{
			return -1;
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		if(ValidDate.validateDate(s)==1)
			System.out.println("valid");
		else
			System.out.println("invalid");
	}
}
