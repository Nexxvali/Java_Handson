import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class DOBValidation 
{
	public static boolean ValidateDOB(String s)
	{
		SimpleDateFormat f;
		if(s.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}")&&s!=null)
			f=new SimpleDateFormat("MM/dd/yyyy");
		else
			return false;
		f.setLenient(false);
		try
		{
			Date d=f.parse(s);
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String s=in.next();
		System.out.println(DOBValidation.ValidateDOB(s));
	}
}
