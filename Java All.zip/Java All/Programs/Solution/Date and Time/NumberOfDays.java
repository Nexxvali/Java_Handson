import java.util.Calendar;
import java.util.Scanner;

public class NumberOfDays 
{
	public static int getNumberOfDays(int year,int monthcode)
	{
		Calendar c=Calendar.getInstance();
		c.set(Calendar.YEAR,year);
		c.set(Calendar.MONTH,monthcode);
		int res=c.getActualMaximum(Calendar.DAY_OF_MONTH);
		if(monthcode==1&res==31)
			return 28;
		return res;
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		int y=in.nextInt();
		int mc=in.nextInt();
		System.out.println(NumberOfDays.getNumberOfDays(y,mc));
	}
}
