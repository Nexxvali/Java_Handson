import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class DateFormatConversion 
{
	public static String convertDateFormat(String d1)
	{
		SimpleDateFormat f;
		if(d1.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}"))
			f=new SimpleDateFormat("dd/MM/yyyy");
		else
			return "";
		f.setLenient(false);
		try
		{
			Date d=f.parse(d1);
			f=new SimpleDateFormat("dd-MM-yy");
			return f.format(d);
		}
		catch(Exception e)
		{
			return "";
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String d1=in.nextLine();
		System.out.println(DateFormatConversion.convertDateFormat(d1));
	}
}
