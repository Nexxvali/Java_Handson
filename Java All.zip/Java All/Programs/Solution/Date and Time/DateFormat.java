import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;


public class DateFormat 
{
	public static String findOldDate(String d1,String d2)
	{
		SimpleDateFormat f;
		if(d1.matches("[0-9]{1,2}-[0-9]{2}-[0-9]{4}")&&d2.matches("[0-9]{1,2}-[0-9]{2}-[0-9]{4}"))
			f=new SimpleDateFormat("dd-MM-yyyy");
		else
			return "";
		f.setLenient(false);
		try
		{
			Date date1=f.parse(d1);
			Date date2=f.parse(d2);
			f=new SimpleDateFormat("MM/dd/yyyy");
			if(date1.compareTo(date2)<0)
				return f.format(date1);
			return f.format(date2);
		}
		catch(Exception e)
		{
			return "";
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String d1=in.nextLine();
		String d2=in.nextLine();
		System.out.println(DateFormat.findOldDate(d1,d2));
	}
}
