import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;


public class ExperienceCalculator 
{
	public static boolean calculateExperience(String d1,String d2,int n)
	{
		SimpleDateFormat f;
		if(d1.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}")&&d2.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}"))
			f=new SimpleDateFormat("dd/MM/yyyy");
		else
			return false;
		f.setLenient(false);
		try
		{
			Calendar date=Calendar.getInstance();
			date.setTime(f.parse(d1));
			int year1=date.get(Calendar.YEAR);
			date.setTime(f.parse(d2));
			int year2=date.get(Calendar.YEAR);
			int diff=Math.abs(year2-year1);
			if(diff==n)
				return true;
			else
				return false;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String d1=in.nextLine();
		String d2=in.nextLine();
		int n=in.nextInt();
		System.out.println(ExperienceCalculator.calculateExperience(d1,d2,n));
	}
}
