import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
import java.util.TimeZone;


public class AddTime 
{
	public static String addTime(String t1,String t2)
	{
		SimpleDateFormat f;
		if(t1.matches("[0-9]{2}:[0-9]{2}:[0-9]{2}")&&t2.matches("[0-9]{2}:[0-9]{2}:[0-9]{2}"))
			f=new SimpleDateFormat("HH:mm:ss");
		else
			return "";
		f.setLenient(false);
		try
		{
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
			Date date1=f.parse(t1); 
			Date date2=f.parse(t2);
			Calendar c=Calendar.getInstance();
			c.setTimeZone(TimeZone.getTimeZone("UTC"));
			c.setTime(date1);
			int h1=c.get(Calendar.HOUR_OF_DAY);
			int m1=c.get(Calendar.MINUTE);
			int s1=c.get(Calendar.SECOND);
			c.setTime(date2);
			int h2=c.get(Calendar.HOUR_OF_DAY);
			int m2=c.get(Calendar.MINUTE);
			int s2=c.get(Calendar.SECOND);
			int d=0,h=h1+h2,m=m1+m2,s=s1+s2;
			if(s>59)
			{
				m++;
				s=s-60;
			}
			if(m>59)
			{
				h++;
				m=m-60;
			}
			if(h>23)
			{
				d++;
				h=h-24;
			}
			return d+":"+h+":"+m+":"+s;
		}
		catch(Exception e)
		{
			return "";
		}
	}
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		String t1=in.nextLine();
		String t2=in.nextLine();
		System.out.println(AddTime.addTime(t1,t2));
	}
}
