package Selenium.amazon;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
	
	public static String ExcelRead() throws Exception
	{
	File src1= new File("D:\\Selenium_Nexxvali\\amazon\\Data1.xlsx");
	FileInputStream fis1 = new FileInputStream(src1);
	//to load entire workbook use XSSFWorkbook class
			XSSFWorkbook wb1 = new XSSFWorkbook(fis1);
			XSSFSheet sheet1 = wb1.getSheetAt(0);
			String data = sheet1.getRow(0).getCell(0).getStringCellValue();
			return data;
}
}
