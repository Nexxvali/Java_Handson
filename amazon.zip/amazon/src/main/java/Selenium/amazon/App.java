package Selenium.amazon;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Hello world!
 *
 */
public class App 
{
	WebDriver driver;
    By search=By.xpath("//input[@id='twotabsearchtextbox']");
    By button=By.id("nav-search-submit-button");
    By items= By.tagName("span");
   
    
    public App(WebDriver driver) {
		// TODO Auto-generated constructor stub
    	this.driver=driver;
	}

	public void search() throws Exception
    {
    	driver.findElement(search).sendKeys(ExcelUtils.ExcelRead());
    }
    
  public void button()
  {
	  driver.findElement(button).click();
  }
  public List allItems()
  {
	  List <WebElement>allitems = driver.findElements(items);
	  return allitems;
  }
    
}
