package Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public  class DriverSetup {
static WebDriver driver;
	
	public static WebDriver browserintiate(String browser_name)
	{
		if(browser_name.equals("chrome"))
		{
		System.setProperty("webdriver.chrome.driver","E:\\SeleniumJARs\\chromedriver.exe");
		 driver=new ChromeDriver();
		driver.manage().window().maximize();
		return driver;
		}
		else 
		{
			System.out.println("no browser");
		}
		return driver;
	}
}
