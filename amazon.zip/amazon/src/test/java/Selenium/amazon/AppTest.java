package Selenium.amazon;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Base.DriverSetup;




/**
 * Unit test for simple App.
 */
public class AppTest 
{
	WebDriver driver;

    @Test
    public void shouldAnswerWithTrue() throws Exception
    {
        File src=new File("D:\\Selenium_Nexxvali\\amazon\\config.properties");
        FileInputStream fis=new FileInputStream(src);
        Properties pro=new Properties();
        pro.load(fis);
		//System.setProperty("webdriver.chrome.driver",pro.getProperty("chromedriver"));
		// driver=new ChromeDriver();
		//driver.get(pro.getProperty("url"));
		
		//driver.manage().window().maximize();
		driver=DriverSetup.browserintiate(pro.getProperty("browserName"));
		driver.get(pro.getProperty("url"));
      App test1=new App(driver);
       test1.search();
       test1.button();
 		List <WebElement>listofitems= test1.allItems(); 
 		
 	    
 	    
 	    for ( int i =0; i<5; i++)
 	    {
 	    	System.out.println(" First five items are : " +listofitems.get(i).getAttribute("class"));
 	    	
 	    }
 		
 		
    }
   
}
