import java.util.*;


public class ArrayListManipulation 
{
	public static ArrayList<Integer> generateOddEvenList(ArrayList<Integer> a1,ArrayList<Integer> a2)
	{
		  ArrayList<Integer> res=new ArrayList<Integer>();
		  int i;
		  for(i=0;i<a1.size();i++)
		  {
			  if(i%2==0)
				  res.add(a2.get(i));
			  else
				  res.add(a1.get(i));
		  }
		  return res;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
		ArrayList<Integer> a1=new ArrayList<Integer>();
        for(int i=0;i<n;i++)
        	a1.add(in.nextInt());
        ArrayList<Integer> a2=new ArrayList<Integer>();
        for(int i=0;i<n;i++)
        	a2.add(in.nextInt());
        for(Integer s:ArrayListManipulation.generateOddEvenList(a1,a2))
        	System.out.println(s);
	}
}
