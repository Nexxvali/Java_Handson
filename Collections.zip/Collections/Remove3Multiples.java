import java.util.ArrayList;
import java.util.Scanner;


public class Remove3Multiples 
{
	public static ArrayList<Integer> removeMultiplesOfThree(ArrayList<Integer> s)
	{
		ArrayList<Integer> a=new ArrayList<Integer>();
		for(int i=0;i<s.size();i++)
			if((i+1)%3!=0)
				a.add(s.get(i));
		return a;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
		ArrayList<Integer> a=new ArrayList<Integer>();
        for(int i=0;i<n;i++)
        	a.add(in.nextInt());
        for(Integer s:Remove3Multiples.removeMultiplesOfThree(a))
        	System.out.println(s);
	}
}
