import java.util.*;

public class EvenSumDuplicate
{
	public static int sumElements(Integer []n)
	{
		int sum=0;
		Set<Integer> s=new HashSet<Integer>(Arrays.asList(n));
		n=new Integer[s.size()];
		s.toArray(n);
		for(int i=0;i<n.length;i++)
			if(n[i]%2==0)
				sum=sum+n[i];
		if(sum==0)
			return -1;
		return sum;
	}
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Integer []a=new Integer[n];
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
			System.out.println(EvenSumDuplicate.sumElements(a));
	}
}
