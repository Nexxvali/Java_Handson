import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class GradeCalculator 
{
	public static LinkedHashMap<String,String> calculateGrade(LinkedHashMap<String,Float> h)
	{
		LinkedHashMap<String,String> newh=new LinkedHashMap<String,String>();
		for(Map.Entry<String,Float> map:h.entrySet())
			if(map.getValue()>=60)
				newh.put(map.getKey(),"PASS");
			else
				newh.put(map.getKey(),"FAIL");
		return newh;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        LinkedHashMap<String,Float> h=new LinkedHashMap<String,Float>();
        for(int i=0;i<n;i++)
        	h.put(in.next(),in.nextFloat());
        for(Map.Entry<String, String> map:GradeCalculator.calculateGrade(h).entrySet())
        	System.out.println(map.getKey()+"\n"+map.getValue());
	}
}
