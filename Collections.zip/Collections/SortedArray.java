import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;

public class SortedArray 
{
	public static String[] orderElements(String[] s)
	{
		HashSet<String> h=new HashSet<String>(Arrays.asList(s));
		String res[]=new String[h.size()];
		h.toArray(res);
		Arrays.sort(res);
		return res;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        String[] a=new String[n];
        for(int i=0;i<n;i++)
        	a[i]=in.nextLine();
        for(String s:SortedArray.orderElements(a))
        	System.out.println(s);
	}
}
