import java.util.HashMap;
import java.util.Scanner;


public class CalculateAverageHashMap 
{
	public static Double calculateAverage(HashMap<Integer,Double> h)
	{
		double avg=0.0;
		int count=0;
		for(Integer i:h.keySet())
			if(i%2!=0)
			{
				avg=avg+h.get(i);
				count++;
			}
		return Math.round((avg/(float)count)*100.0)/100.0;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        HashMap<Integer,Double> h=new HashMap<Integer,Double>();
        for(int i=0;i<n;i++)
        	h.put(in.nextInt(),in.nextDouble());
        System.out.println(CalculateAverageHashMap.calculateAverage(h));
	}
}
