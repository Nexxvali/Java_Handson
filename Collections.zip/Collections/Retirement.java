import java.text.SimpleDateFormat;
import java.util.*;

public class Retirement 
{
    public static ArrayList<String>  retirementEmployeeList(HashMap<String,String> hm)
    {
    	SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy");
    	ArrayList<String> l=new ArrayList<String>();
    	try
	    {
	    	Date d=f.parse("01/01/2014");
	       	Calendar c=Calendar.getInstance();
	       	c.setTime(d);
	    	int cur=c.get(Calendar.YEAR);
	    	for(Map.Entry<String,String> map:hm.entrySet())
	    	{
	    		Date d1=f.parse(map.getValue());
	    		c.setTime(d1);
	    		int dob=c.get(Calendar.YEAR);
	    		if(cur-dob>=60)
	    		l.add(map.getKey());
	    	}
	    }
	    catch(Exception e)
	    {
	    	return null;
	   	}
	   	Collections.sort(l);
	   	return l;
    }
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=Integer.parseInt(sc.nextLine());
		LinkedHashMap<String,String>a1=new LinkedHashMap<String,String>();
		for(int i=0;i<n;i++)
			a1.put(sc.nextLine(),sc.nextLine());
		ArrayList<String> l1=new ArrayList<String>();
		l1=Retirement.retirementEmployeeList(a1);
		System.out.println(l1);
	}
}
