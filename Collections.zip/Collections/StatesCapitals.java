import java.util.HashMap;
import java.util.Scanner;

public class StatesCapitals 
{
	public static String getCapital(HashMap<String,String> h,String search)
	{
		String res=h.get(search);
		res=res+"$"+search;
		return res;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        HashMap<String,String> h=new HashMap<String,String>();
        for(int i=0;i<n;i++)
        	h.put(in.next(),in.next());
        String search=in.next();
        System.out.println(StatesCapitals.getCapital(h,search));
	}
}
