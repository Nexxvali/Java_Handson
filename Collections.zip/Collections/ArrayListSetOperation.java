import java.util.*;


public class ArrayListSetOperation 
{
	public static ArrayList<Integer> performSetOperations(ArrayList<Integer> s1,ArrayList<Integer> s2,char c)
	{
		ArrayList<Integer> s=new ArrayList<Integer>();
		switch(c)
		{
		case '+':
			s=new ArrayList<Integer>(s1);
			s.addAll(s2);
			break;
		case '*':
			s=new ArrayList<Integer>(s1);
			s.retainAll(s2);
			break;
		case '-':
			s=new ArrayList<Integer>(s1);
			s.removeAll(s2);
			break;
		}
		return s;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
		ArrayList<Integer> s1=new ArrayList<Integer>();
        for(int i=0;i<n;i++)
        	s1.add(Integer.parseInt(in.nextLine()));
        n=Integer.parseInt(in.nextLine());
        ArrayList<Integer> s2=new ArrayList<Integer>();
        for(int i=0;i<n;i++)
        	s2.add(Integer.parseInt(in.nextLine()));
        char c=in.nextLine().charAt(0);
        for(Integer i:ArrayListSetOperation.performSetOperations(s1,s2,c))
        	System.out.println(i);
	}
}