import java.util.*; 
import java.text.SimpleDateFormat;

public class InterestCalculation
{
	public static TreeMap<String,Integer> display (HashMap<String,String>hm,HashMap<String,Integer>hm1)
	{
		int year=0,amount=0;
		double dis=0;
		String now="01/01/2015";
		TreeMap<String,Integer>tm=new TreeMap<String,Integer>();
		for(String s:hm.keySet())
		{
			String id=s;
			String dor=hm.get(id);
			amount=hm1.get(id);
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			SimpleDateFormat sdf1=new SimpleDateFormat("dd/MM/yyyy");
			try
			{
				Calendar c=Calendar.getInstance();
				Date d1=sdf.parse(dor);
				Date d2=sdf1.parse(now);
				c.setTime(d1);
				int y1=c.get(Calendar.YEAR);
				int m1=c.get(Calendar.MONTH);
				int d11=c.get(Calendar.DATE);
				c.setTime(d2);
				int y2=c.get(Calendar.YEAR);
				int m2=c.get(Calendar.MONTH);
				int d22=c.get(Calendar.DATE);
				year=Math.abs(y2-y1);
				if(m1>m2)
					year--;
				else if(m2==m1 && d11>d22)
					year--;
				if(year>=60)
					dis=0.1*amount+amount;
				else if(year<60 && year>=30 )
					dis=0.07*amount+amount;
				else
					dis=0.04*amount+amount;
				tm.put(id,(int)dis);
			
			}
			catch(Exception e)
			{
				return null;
			}
		}
		return tm;
	}
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		int s=Integer.parseInt(sc.nextLine());
		HashMap<String,String>hm=new HashMap<String,String>();
		HashMap<String,Integer>hm1=new HashMap<String,Integer>();
		for(int i=0;i<s;i++)
		{
		String id=sc.nextLine();
		hm.put(id, sc.nextLine());
		hm1.put(id,Integer.parseInt(sc.nextLine()));
		 
		}
		for(Map.Entry<String, Integer> map:InterestCalculation.display(hm,hm1).entrySet())
			System.out.println(map.getKey()+":"+map.getValue());
	}
}
