import java.util.*;

public class ManagersAndHashMap 
{
	public static HashMap<Integer,Integer> increaseSalarieswhich(HashMap<Integer,String>hm,HashMap<Integer,Integer>hm1)
	{
		HashMap<Integer,Integer> h=new HashMap<Integer,Integer>();
		for(Map.Entry<Integer,String> map:hm.entrySet())
		{
			for(Map.Entry<Integer,Integer> map1:hm1.entrySet())
			{
				if(map.getKey()==map1.getKey())
					if(map.getValue().equalsIgnoreCase("manager"))
						h.put(map.getKey(),map1.getValue()+5000);
			}
		}
		return h;
	}
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		int s=Integer.parseInt(sc.nextLine());
		HashMap<Integer,String>hm=new HashMap<Integer,String>();
		HashMap<Integer,Integer>hm1=new HashMap<Integer,Integer>();
		for(int i=0;i<s;i++)
		{
			int id=Integer.parseInt(sc.nextLine());
			hm.put(id, sc.nextLine());
			hm1.put(id,Integer.parseInt(sc.nextLine()));
		}
		for(Map.Entry<Integer, Integer> map:ManagersAndHashMap.increaseSalarieswhich(hm,hm1).entrySet())
			System.out.println(map.getKey()+":"+map.getValue());
	}
}
