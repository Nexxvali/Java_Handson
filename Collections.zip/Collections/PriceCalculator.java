import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PriceCalculator 
{
	public static float costEstimator(HashMap<String,Float> h,String s[])
	{
		float price=0.0f;
		for(String i:s)
		{
			for(Map.Entry<String,Float> map:h.entrySet())
			{
				if(map.getKey().equals(i))
				{
					price=price+map.getValue();
					break;
				}
			}
		}
		return (price*100.0f)/100.0f;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        HashMap<String,Float> h=new HashMap<String,Float>();
        for(int i=0;i<n;i++)
        	h.put(in.nextLine(),Float.parseFloat(in.nextLine()));
        n=Integer.parseInt(in.nextLine());
        String s[]=new String[n];
        for(int i=0;i<n;i++)
        	s[i]=in.nextLine();
        System.out.println(PriceCalculator.costEstimator(h,s));
	}
}
