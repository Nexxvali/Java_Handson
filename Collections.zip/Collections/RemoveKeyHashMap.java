import java.util.HashMap;
import java.util.Scanner;

public class RemoveKeyHashMap 
{
	public static int sizeOfResultandHashMap(HashMap<Integer,String> h)
	{
		int size=0;
		for(Integer i:h.keySet())
			if(i%4!=0)
				size++;
		return size;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        HashMap<Integer,String> h=new HashMap<Integer,String>();
        for(int i=0;i<n;i++)
        	h.put(in.nextInt(),in.next());
        System.out.println(RemoveKeyHashMap.sizeOfResultandHashMap(h));
	}
}
