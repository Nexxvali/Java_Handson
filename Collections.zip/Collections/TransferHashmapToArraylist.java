import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;

public class TransferHashmapToArraylist 
{
	public static ArrayList<String> getName(HashMap<Integer,String> h)
	{
		Collection<String> c=h.values();
		ArrayList<String> l=new ArrayList<String>(c);
		for(int i=0;i<l.size();i++)
			if(!(l.get(i).matches("^[a-z].*")&&l.get(i).matches(".*[A-Z]$")&&l.get(i).matches(".*[0-9].*")))
				l.remove(i);
		return l;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        HashMap<Integer,String> h=new HashMap<Integer,String>();
        for(int i=0;i<n;i++)
        	h.put(in.nextInt(),in.next());
        for(String s:TransferHashmapToArraylist.getName(h))
        	System.out.println(s);
	}
}
