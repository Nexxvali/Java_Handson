import java.util.*;

public class ElementsArrayList
{
	public static Integer[] arrayListSubtractor(ArrayList<Integer> a1,ArrayList<Integer> a2)
	{
		Set<Integer> set1=new HashSet<Integer>(a1);
		Set<Integer> set2=new HashSet<Integer>(a2);
		Set<Integer> set12=new HashSet<Integer>(set1);
		set12.removeAll(set2);
		Set<Integer> set21=new HashSet<Integer>(set2);
		set21.removeAll(set1);
		Set<Integer> sub=new HashSet<Integer>(set12);
		sub.addAll(set21);
		Integer res[]=new Integer[sub.size()];
		sub.toArray(res);
		Arrays.sort(res);
		return res;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
		ArrayList<Integer> a1=new ArrayList<Integer>();
        for(int i=0;i<n;i++)
        	a1.add(in.nextInt());
        n=in.nextInt();
        ArrayList<Integer> a2=new ArrayList<Integer>();
        for(int i=0;i<n;i++)
        	a2.add(in.nextInt());
        for(Integer s:ElementsArrayList.arrayListSubtractor(a1,a2))
        	System.out.println(s);
	}
}
