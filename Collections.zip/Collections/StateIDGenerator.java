import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;


public class StateIDGenerator 
{
	public static LinkedHashMap<String,String> getStateId(String s[])
	{
		LinkedHashMap<String,String> h=new LinkedHashMap<String,String>();
		for(int i=0;i<s.length;i++)
	        	h.put(s[i].substring(0,3).toUpperCase(),s[i]);
		return h;
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        String s[]=new String[n];
        for(int i=0;i<n;i++)
        	s[i]=in.next();
        for(Map.Entry<String, String> map:StateIDGenerator.getStateId(s).entrySet())
        	System.out.println(map.getKey()+":"+map.getValue());
	}
}
