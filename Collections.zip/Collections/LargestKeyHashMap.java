import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class LargestKeyHashMap 
{
	public static String getMaxKeyValue(HashMap<Integer,String> h)
	{
		Collection<Integer> c=h.keySet();
		List<Integer> l=new ArrayList<Integer>(c);
		Collections.sort(l);
		return h.get(l.get(l.size()-1));
		/*Set<Integer> s=h.keySet();
		Integer a[]=new Integer[s.size()];
		s.toArray(a);
		Arrays.sort(a);
		return h.get(a[a.length-1]);*/			
	}
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=Integer.parseInt(in.nextLine());
        HashMap<Integer,String> h=new HashMap<Integer,String>();
        for(int i=0;i<n;i++)
        	h.put(in.nextInt(),in.next());
        System.out.println(LargestKeyHashMap.getMaxKeyValue(h));
	}
}
